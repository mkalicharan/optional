# other imports
from sys import warnoptions
from os import getcwd, mkdir, startfile
from os.path import exists, isdir, basename, join
import gc
#import logging
from shutil import rmtree, copy
from time import sleep
from glob import glob
from win32api import SetFileAttributes
import win32con

# processing imports
from PyPDF2 import PdfFileReader
from pdfminer.pdfparser import PDFParser
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdfinterp import resolve1
from pdf2jpg.pdf2jpg import convert_pdf2jpg
#from subprocess import Popen
from extract_text_and_cordinates import textandcordinates
from adjust_orientation import auto_orient
from pyautogui import size as screensize
import cv2
import numpy as np
from PIL import Image, ImageTk

# SQL & Sendmail imports
import base64
from datetime import datetime
from socket import gethostname
from getpass import getuser
from ldap3 import Server, Connection, ALL
import pyodbc
from smtplib import SMTP
from email.mime.multipart import MIMEMultipart
from email import encoders
from email.mime.base import MIMEBase

if not warnoptions:
    import warnings

    warnings.simplefilter("ignore")

# disable Decompression Bombs Exceptions
Image.MAX_IMAGE_PIXELS = None

g_project = 'pdfsatya'
g_old_path = ''
g_new_path = ''
g_output_path = ''
g_processing_path = ''
g_error_present = False
g_coutpages = False
g_pagecount = 0
g_old_pdf_filenames = {}
g_new_pdf_filenames = {}
g_check_calibration = 0  # -1 for manual, 1 for auto and 0 for no Calibration


# These functions are utility functions
# This function adds the no of units run by the program everytime to the license.txt file. It also adds junk
def add_units_locking(units):
    junk = '''Machine learning is an application of artificial intelligence (AI) that provides systems the ability to automatically learn and improve from experience without being explicitly programmed. Machine learning focuses on the development of computer programs that can access data and use it learn for themselves.The process of learning begins with observations or data, such as examples, direct experience, or instruction, in order to look for patterns in data and make better decisions in the future based on the examples that we provide. The primary aim is to allow the computers learn automatically without human intervention or assistance and adjust actions accordingly.Some machine learning methodsMachine learning algorithms are often categorized as supervised or unsupervised.Supervised machine learning algorithms can apply what has been learned in the past to new data using labeled examples to predict future events. Starting from the analysis of a known training dataset, the learning algorithm produces an inferred function to make predictions about the output values. The system is able to provide targets for any new input after sufficient training. The learning algorithm can also compare its output with the correct, intended output and find errors in order to modify the model accordingly.In contrast, unsupervised machine learning algorithms are used when the information used to train is neither classified nor labeled. Unsupervised learning studies how systems can infer a function to describe a hidden structure from unlabeled data. The system doesn’t figure out the right output, but it explores the data and can draw inferences from datasets to describe hidden structures from unlabeled data.Semi-supervised machine learning algorithms fall somewhere in between supervised and unsupervised learning, since they use both labeled and unlabeled data for training – typically a small amount of labeled data and a large amount of unlabeled data. The systems that use this method are able to considerably improve learning accuracy. Usually, semi-supervised learning is chosen when the acquired labeled data requires skilled and relevant resources in order to train it / learn from it. Otherwise, acquiringunlabeled data generally doesn’t require additional resources.Reinforcement machine learning algorithms is a learning method that interacts with its environment by producing actions and discovers errors or rewards. Trial and error search and delayed reward are the most relevant characteristics of reinforcement learning. This method allows machines and software agents to automatically determine the ideal behavior within a specific context in order to maximize its performance. Simple reward feedback is required for the agent to learn which action is best; this is known as the reinforcement signal.Machine learning enables analysis of massive quantities of data. While it generally delivers faster, more accurate results in order to identify profitable opportunities or dangerous risks, it may also require additional time and resources to train it properly. Combining machine learning with AI and cognitive technologies can make it even more effective in processing large volumes of information.'''
    units = int(units)
    f = open("./data/license.txt", "r")
    decoded = base64.b64decode(f.read())
    value = get_units_licence(decoded)
    value = value + units
    value = str(value)
    f.close()

    encoded = junk + junk + junk + junk + ' ' + value + ' ' + junk + junk
    encoded = base64.b64encode(encoded.encode('utf_8'))
    hs = open("./data/license.txt", 'wb')

    hs.write(encoded)
    hs.close()


# This function is responsible for getting the actual runs of program (no.)
def get_units_licence(str):
    a = [int(s) for s in str.split() if s.isdigit()]
    return a[0]


# This function checks for absoulte expiry. Meaning that it checks for the license.txt exceeding 300 files
def check_expiry_for_holds():
    try:
        f = open("./data/license.txt", "r")
        decoded = base64.b64decode(f.read())
        value = get_units_licence(decoded)
        return value
    except:
        #logging.exception("Check_Expiry Exception\n")
        raise


def get_mail_country_and_location(input_email):
    try:
        host, user, password = 'LDAP://WorleyParsons.com', 'automation.anywhere', 'Auto@AnyIndia99'
        searchfilter = '(sAMAccountName=' + input_email.split('@')[0] + ')'

        server = Server(host, get_info=ALL)
        conn = Connection(server, user, password, auto_bind=True, check_names=True)
        conn.search('dc=WorleyParsons,dc=com', searchfilter, attributes=['co', 'displayName', 'mail'])

        for info in conn.entries:
            info = str(info).split("\r\n")
            Country = str(info[1]).strip().split("co: ")[1]
            Location = (str(info[2]).strip().split("(")[1])[:-1]
            mail = str(info[3]).strip().split("mail: ")[1]

        return Country, Location, mail

    except:
        # if user is not in Worley's domain, check in Jacobs' domain
        try:
            host, user, password = 'ldap.europe.jacobs.com', r'JEGINTL\injbot001', '3hYN##dP@$sw0rd'
            searchfilter = '(mail=' + input_email + ')'

            server = Server(host, get_info=ALL)
            conn = Connection(server, user, password, auto_bind=True)
            conn.search('dc=europe,dc=jacobs,dc=com', searchfilter, attributes=['co', 'displayName', 'mail'])

            for info in conn.entries:
                info = str(info).split("\r\n")
                Country = str(info[1]).strip().split("co: ")[1]
                mail = str(info[3]).strip().split("mail: ")[1]
                Location = info[0].split(',')[3][3:]

            return Country, Location, mail

        except:
            # logging.exception('Error in "get_mail_country_and_location" function')
            return 'noinfo', 'noinfo', 'noinfo'


def sql_connection_status_worley(server, database, username, password):
    global cnxn
    try:
        cnxn = pyodbc.connect('DRIVER={' + pyodbc.drivers()[
            0] + '};SERVER=' + server + ';DATABASE=' + database + ';UID=' + username + ';PWD=' + password)
        return True
    except:
        # logging.exception('Error in "sql_connection_status_worley" function')
        return False


def storing_in_db_worley(TaskName, StartDateTime, EndDateTime, Status, LoggedInUser, MachineName, Country, Location,
                         AutomationType, NoOfUnits):
    try:
        server, database, username, password = 'SGSDCWPSQL89v', 'GDCSRPAData', 'automation.anywhere', 'WPautomation.anywhere01'
        if sql_connection_status_worley(server, database, username, password):
            if cnxn != None:
                cursor = cnxn.cursor()
                cursor.execute("Insert into BotExecutionTimeLog values (?,?,?,?,?,?,?,?,?,?)", TaskName, StartDateTime,
                               EndDateTime, Status, LoggedInUser, MachineName, Country, Location, AutomationType,
                               NoOfUnits)
                cnxn.commit()
        else:
            storing_in_db_jacobs(g_project.title(),StartDateTime,EndDateTime,Status,
                        LoggedInUser,MachineName,Country,Location,"DATA SCIENCE SCRIPT",str(NoOfUnits))
    except:
        # logging.exception("SQL exception")
        pass


def sql_connection_status_jacobs(server, database):
    global cnxn
    try:
        cnxn = pyodbc.connect('DRIVER={' + pyodbc.drivers()[
            0] + '};SERVER=' + server + ';DATABASE=' + database + ';Trusted_Connection=yes;')
        return True
    except:
        # logging.exception('Error in "sql_connection_status_jacobs" function')
        return False


def storing_in_db_jacobs(TaskName, StartDateTime, EndDateTime, Status, LoggedInUser, MachineName, Country, Location,
                         AutomationType, NoOfUnits):
    server, database, username, password = 'innmb4-sql018', 'AutomationTracker', 'injbot001', '3hYN##dP@$sw0rd'
    if sql_connection_status_jacobs(server, database):
        if cnxn != None:
            cursor = cnxn.cursor()
            cursor.execute("Insert into BotExecutionTimeLog values (?,?,?,?,?,?,?,?,?,?)", TaskName, StartDateTime,
                           EndDateTime, Status, LoggedInUser, MachineName, Country, Location, AutomationType,
                           NoOfUnits)
            cnxn.commit()


# This is used to send the mail to ourselves
def sendmail(log_file_name):
    # set up the SMTP server
    # host, port, username, password, receivers = get_user_details()
    host, port, username, password, receivers = 'smtp-mail.outlook.com', '587', 'Automation.Anywhere@worleyparsons.com', 'Auto@AnyIndia99', 'dhairya.patel@worleyparsons.com'
    server = SMTP(host=host, port=port)
    server.starttls()
    server.login(username, password)

    # Send the email to all the receivers:
    receiver_list = receivers.split(",")
    for receiver in receiver_list:
        msg = MIMEMultipart()  # create a message
        # open the file to be sent
        filename = basename(log_file_name)
        # short_filename=filename[filename.rfind('/')+1:]
        attachment = open(filename, 'rb')

        # instance of MIMEBase invoked
        instance_mimebase = MIMEBase('application', 'octet-stream')

        # To change the payload into encoded form
        instance_mimebase.set_payload((attachment).read())

        # encode into base64
        encoders.encode_base64(instance_mimebase)

        instance_mimebase.add_header('Content-Disposition', "attachment; filename= %s" % 'PDFCompare_' + filename)

        # setup the parameters of the message
        msg['From'] = username
        msg['To'] = receiver
        msg['Subject'] = "Log file for PDFCompare"

        # add in the message body
        msg.attach(instance_mimebase)

        # send the message via the server set up earlier.
        server.send_message(msg)
        del msg

    # Terminate the SMTP session and close the connection
    server.quit()


# when details are in a config file
def get_user_details():
    with open('./data/Details.ini') as database_file:
        content = database_file.readlines()
    content = [line.strip() for line in content]
    host = content[0].split("=")[1]
    port = int(content[1].split("=")[1])
    username = content[2].split("=")[1]
    password = content[3].split("=")[1]
    receivers = content[4].split("=")[1]
    return host, port, username, password, receivers


# Processing functions start here
def makepdf(pdf_outpath, old_pdf):
    listimages = [Image.open(img) for img in glob(g_processing_path + "\\" + basename(old_pdf) + "\\*.jpg")]

    try:
        if len(listimages) == 1:
            listimages[0].save(pdf_outpath, "PDF", resolution=100.0, save_all=True)
        else:
            listimages[0].save(pdf_outpath, "PDF", resolution=100.0, save_all=True, append_images=listimages[1:])
    except:
        #logging.info("{} present in the output directory maybe open in other processes\
            #\n\nPlease close it and proceed".format(basename(pdf_outpath)))

        try:
            if len(listimages) == 1:
                listimages[0].save(pdf_outpath, "PDF", resolution=100.0, save_all=True)
            else:
                listimages[0].save(pdf_outpath, "PDF", resolution=100.0, save_all=True, append_images=listimages[1:])
        except:
            #logging.info("Unable to save the file {}\n\nPlease run the program again for this file".format(
                #basename(pdf_outpath), basename(pdf_outpath)))
            pass

        """
        #this block is to deal with Decompression Bombs Exception (even though we have explicitly switched it off on line 46)
        totalpixels = lambda width, height: width*height

        scalingfactor = lambda img: 178956970 / totalpixels(img.size[0], img.size[1])

        #Image.LANCZOS is a high-quality downsampling filter
        listimages = list(map(lambda img: img if totalpixels(img.size[0], img.size[1]) <= 178956970 else
            img.resize((img.size[0]/scalingfactor(img), img.size[1]/scalingfactor(img)), resample = Image.LANCZOS), listimages))

        listimages[0].save(pdf_outpath, "PDF" , resolution=100.0, save_all=True, append_images=listimages[1:])
        """

    del listimages


# This function highlights the text which is same in both pages
def highlighttext(oldpdf_textinpage, oldpdf_cordinates, newpdf_textinpage, newpdf_cordinates,
                  blended_image, original_image_dimensions, cutdimensions, angle):
    h1, w1, _ = original_image_dimensions[0]
    h2, w2, _ = original_image_dimensions[1]
    h3, w3, _ = blended_image.shape

    # set 0.5% thresholds to control text shifts
    wthreshold = 0.05 * w3
    hthreshold = 0.05 * h3

    xcut1, ycut1 = cutdimensions[0][0], cutdimensions[0][1]
    xcut2, ycut2 = cutdimensions[1][0], cutdimensions[1][1]

    for text, text_coordinates in zip(oldpdf_textinpage, oldpdf_cordinates):
        startX, startY, endX, endY = text_coordinates

        # to scale according to image
        # image_x = pdf_x * image_width / pdfpage_width
        # image_y = (pdfpage_height - pdf_y) * image_height / pdfpage_height

        # adjust the cordinates wrt to region selected
        startX = int(startX * w1) - xcut1
        startY = int(startY * h1) - ycut1
        endX = int(endX * w1) - xcut1
        endY = int(endY * h1) - ycut1

        for entry, entry_cordinates in zip(newpdf_textinpage, newpdf_cordinates):
            if text == entry:
                entry_startX, entry_startY, entry_endX, entry_endY = entry_cordinates

                # adjust the cordinates wrt to region selected
                entry_startX = int(entry_startX * w2) - xcut2
                entry_startY = int(entry_startY * h2) - ycut2
                entry_endX = int(entry_endX * w2) - xcut2
                entry_endY = int(entry_endY * h2) - ycut2

                # adjust the cordinates if image has been rotated
                if angle == 90:
                    entry_startX, entry_startY = -entry_startY, entry_startX
                    entry_endX, entry_endY = -entry_endY, entry_endX
                elif angle == 180:
                    entry_startX, entry_startY = -entry_startX, -entry_startY
                    entry_endX, entry_endY = -entry_endX, -entry_endY
                elif angle == 270:
                    entry_startX, entry_startY = entry_startY, -entry_startX
                    entry_endX, entry_endY = entry_endY, -entry_endX

                # highlight text region if its within locality and if the region actually contains text
                if abs(startX - entry_startX) < wthreshold and abs(startY - entry_startY) < hthreshold:
                    # since cordinates are in terms of pdf, (0,0) is bottom left and hence min max in y in inverted
                    startX = min(startX, entry_startX)
                    startY = max(startY, entry_startY)
                    endX = max(endX, entry_endX)
                    endY = min(endY, entry_endY)
                    cv2.rectangle(blended_image, (startX, startY), (endX, endY), (255, 0, 0), 7)
                    

    del h1, w1, h2, w2, xcut1, ycut1, xcut2, ycut2
    return blended_image


# This function modifies image contents to specified colortuple
def imageprocessing(image, colortuple):
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    height, width, _ = image.shape

    # edge detection is added since adaptive thresholding may miss out on smaller finer details
    detect_edge = cv2.Canny(gray_image, 100, 200)
    
    thresholded1 = cv2.adaptiveThreshold(gray_image, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                        cv2.THRESH_BINARY_INV, 21, 21)
    
    # Otsu's thresholding, picks up black foreground blocks which adaptive thresholding misses out
    _, thresholded2 = cv2.threshold(gray_image, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    
    processed = cv2.bitwise_or(detect_edge, thresholded1)
    processed = cv2.bitwise_or(processed, thresholded2)
    del gray_image, detect_edge, thresholded1, thresholded2

    indices = np.where(processed[:height, :width] != 0)
    for x, y in zip(indices[0], indices[1]):
        image[x, y] = colortuple

    del height, width, processed

    return image


# This function returns the largest rectangle of the image
def extractdata(image):
    """ logic to extract largest rectangle -
    1. perform dilation with a big kernel to fill out spaces,
    2. detect the edges after performing dilation,
    3. find contours on these edges, and
    4. store the one with largest width
    """

    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (20, 20))
    processed = cv2.dilate(cv2.bitwise_not(gray_image), kernel)
    del gray_image, kernel

    detect_edge = cv2.Canny(processed, 100, 200)
    del processed

    contours, _ = cv2.findContours(detect_edge, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    del detect_edge

    height, width, _ = image.shape

    """
    largest_rectangle = [[0, 0, 0, 0]]
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        if w != width and h != height:
            if w > largest_rectangle[0][2]:
                largest_rectangle[0] = [x, y, w, h]
        del x, y, w, h

    """

    # construct the list of bounding boxes and sort them based on width + height of the box
    boundingBoxes = [cv2.boundingRect(contour) for contour in contours]
    boundingBoxes.sort(key = lambda box: box[2] + box[3], reverse = True)

    del contours, height, width

    return boundingBoxes[0]


# This function returns the automatically selected region of the image
def autocalibrate(image1, image2):
    try:
        cordinates1 = extractdata(image1)
        cordinates2 = extractdata(image2)

        # records the selected regions cordinates to later adjust text highlights
        cutdimensions = []
        startX, startY, width, height = cordinates1
        image1 = image1[startY:startY + height, startX:startX + width]
        cutdimensions.append((startX, startY))

        startX, startY, width, height = cordinates2
        image2 = image2[startY:startY + height, startX:startX + width]
        cutdimensions.append((startX, startY))

        del cordinates1, cordinates2, startX, startY, width, height

    except:
        cutdimensions = [(0, 0), (0, 0)]
        #logging.exception("Error in automatic calibration")

    finally:
        return image1, image2, cutdimensions


def manualevent(event, x, y, flags, param):
    global calibration_points
    # if the left mouse button was clicked, record the starting (x, y) coordinates
    if event == cv2.EVENT_LBUTTONDOWN:
        calibration_points.append((x, y))

    # check to see if the left mouse button was released
    elif event == cv2.EVENT_LBUTTONUP:
        # record the ending (x, y) coordinates
        calibration_points.append((x, y))
        cv2.rectangle(display_image, calibration_points[0], calibration_points[1], (255, 0, 0), 2)


# This function returns the manually selected region of the image
def manualcalibrate(image):
    try:
        global calibration_points
        calibration_points = []
        global display_image

        screen_width, screen_height = screensize()

        window = 'image'
        cv2.namedWindow(window)
        windowX = int((screen_width - (screen_width * 0.85)) / 2)
        windowY = int((screen_height - (screen_height * 0.85)) / 2)
        cv2.moveWindow('image', windowX, windowY)  # center the window
        cv2.setMouseCallback(window, manualevent)

        # make a copy of the image and resize it to fit screen dimensions
        image_copy = cv2.resize(image, (int(screen_width * 0.85), int(screen_height * 0.85)),
                                interpolation=cv2.INTER_AREA)
        # gamma correct the image for better viewing
        image_copy = np.array(255 * (image_copy / 255) ** 3, dtype='uint8')
        # image to display onto cv2 window
        display_image = image_copy.copy()

        # variable to indicate when user does not want to calibrate
        nocalibration = False

        # keep looping until the 'q' key is pressed
        while True:
            # display the image and wait for a keypress
            cv2.imshow(window, display_image)
            key = cv2.waitKey(1) & 0xFF

            # if the 'b' key is pressed, reset the cropping region
            if key == ord("b"):
                if len(calibration_points) > 0: calibration_points.clear()
                display_image = image_copy.copy()

            # if the 'r' key is pressed, rotate the image
            elif key == ord("r"):
                image = cv2.rotate(image, cv2.ROTATE_90_CLOCKWISE)
                image_copy = cv2.resize(image, (int(screen_width * 0.85), int(screen_height * 0.85)),
                                        interpolation=cv2.INTER_AREA)
                image_copy = np.array(255 * (image_copy / 255) ** 3, dtype='uint8')
                display_image = image_copy.copy()

            # if the 'n' key is pressed, break from the loop
            elif key == ord("n"):
                if len(calibration_points) != 2:
                    #logging.info("Incorrect Selection")
                    calibration_points.clear()
                    display_image = image_copy.copy()
                elif len(calibration_points) == 0:
                    nocalibration = True
                else:
                    break

        cv2.destroyWindow(window)

        # record selection points
        xcut, ycut = 0, 0

        # if image has been calibrated
        if not nocalibration:
            image_height, image_width, _ = image.shape

            # adjust points according to image size
            startX = calibration_points[0][0]
            endX = calibration_points[1][0]
            startY = calibration_points[0][1]
            endY = calibration_points[1][1]

            startX = int((startX * image_width) / (screen_width * 0.85))
            endX = int((endX * image_width) / (screen_width * 0.85))
            startY = int((startY * image_height) / (screen_height * 0.85))
            endY = int((endY * image_height) / (screen_height * 0.85))

            image = image[startY:endY, startX:endX]

            xcut, ycut = startX, startY

        del calibration_points, window, image_copy, display_image, nocalibration, screen_width, \
            screen_height, image_height, image_width, startX, startY, endX, endY

    except:
        #logging.exception("Error in manual calibration")
        pass

    finally:
        return image, xcut, ycut


# This function compares each page of the pdfs
def extractdifference(old_img, new_img, old_pdf, oldpdf_textinpage, oldfpdf_cordinates, newpdf_textinpage,
                      newpdf_cordinates):
    image1 = cv2.imread(old_img)
    image2 = cv2.imread(new_img)

    # store the original image dimensions to scale text regions when calibrated
    original_image_dimensions = [image1.shape, image2.shape]

    # set angle as 0, if auto oriented angle will take the return value
    angle = 0

    cutdimensions = [(0, 0), (0, 0)]  # for scaling text when image is calibrated
    if g_check_calibration == -1:
        image1, xcut1, ycut1 = manualcalibrate(image1)
        image2, xcut2, ycut2 = manualcalibrate(image2)
        cutdimensions[0], cutdimensions[1] = (xcut1, ycut1), (xcut2, ycut2)

        image1_acalibrated, image2_acalibrated, cutdimensions_auto = autocalibrate(image1, image2)

        # check if the image after calibration is a valid selection
        h1, w1, _ = image1.shape
        h2, w2, _ = image1_acalibrated.shape

        cropthreshold = 0.75
        revertcrop = False
        if w2 / w1 < cropthreshold or h2 / h1 < cropthreshold:
            revertcrop = True

        del h1, w1, h2, w2

        h1, w1, _ = image2.shape
        h2, w2, _ = image2_acalibrated.shape

        if w2 / w1 < cropthreshold or h2 / h1 < cropthreshold:
            revertcrop = True

        if not revertcrop:
            del image1, image2
            image1 = image1_acalibrated.copy()
            image2 = image2_acalibrated.copy()
            cutdimensions = cutdimensions_auto

        del h1, w1, h2, w2, cropthreshold, revertcrop, image1_acalibrated, image2_acalibrated

    elif g_check_calibration == 1:
        image1, image2, cutdimensions = autocalibrate(image1, image2)
        # correct the orientations of the images so that they can be overlayed
        # angle stores the angle of rotation of second image wrt base image
        image1, image2, angle = auto_orient(image1, image2)

    if image1.shape != image2.shape:
        h1, w1, _ = image1.shape
        h2, w2, _ = image2.shape

        # if image1 is larger in terms of height
        if (h1 > h2):
            # resize image 1 to image 2 dimensions
            # default cv2 interpolation is cv.INTER_LINEAR which is better when upscaling
            # cv.INTER_CUBIC can also be used for downscaling
            image1 = cv2.resize(image1, (int(w2), int(h2)), interpolation=cv2.INTER_AREA)

            # adjust the text cordinates since image is resized
            ratioW, ratioH = w2 / w1, h2 / h1
            oldfpdf_cordinates = list(map(lambda cordinates: [cordinates[0] * ratioW, cordinates[1] * ratioH, \
                                                              cordinates[2] * ratioW, cordinates[3] * ratioH],
                                          oldfpdf_cordinates))
        else:
            # resize image 2 to image 1 dimensions
            image2 = cv2.resize(image2, (int(w1), int(h1)), interpolation=cv2.INTER_AREA)

            # adjust the text cordinates since image is resized
            ratioW, ratioH = w1 / w2, h1 / h2
            newpdf_cordinates = list(map(lambda cordinates: [cordinates[0] * ratioW, cordinates[1] * ratioH, \
                                                             cordinates[2] * ratioW, cordinates[3] * ratioH],
                                         newpdf_cordinates))

        del h1, w1, h2, w2, ratioW, ratioH

    path_to_save = g_processing_path + "\\" + basename(old_pdf) + "\\" + basename(old_img).split("_")[0]

    # (15, 15, 255) for Bluebeam red (0, 196, 0) for Bluebeam green
    image1 = imageprocessing(image1, (0, 215, 0))
    image2 = imageprocessing(image2, (0, 0, 255))
    blended_image = np.minimum(image1, image2)

    
    """ code to highlight text regions
    # if there is text in both pages highlight same text
    if len(oldpdf_textinpage) > 0 and len(newpdf_textinpage) > 0:
        blended_image = highlighttext(oldpdf_textinpage, oldfpdf_cordinates, \
                                      newpdf_textinpage, newpdf_cordinates, blended_image, original_image_dimensions,
                                      cutdimensions, angle)
    """


    # try-except to avoid memory error
    try:
        gamma_corrected = np.array(255 * (blended_image / 255) ** 3, dtype=blended_image.dtype)
        cv2.imwrite(path_to_save + '_output.jpg', gamma_corrected)
    except:
        cv2.imwrite(path_to_save + '_output.jpg', blended_image)

    del image1, image2, blended_image, gamma_corrected, path_to_save


# This function compares current set of pdfs
def compare(old_pdf, new_pdf):
    # make a new folder within the processing path with corresponding filename
    mkdir(g_processing_path + "\\" + basename(old_pdf))
    #logging.info("Folder created in processing path for file {} \n".format(g_old_pdf_filenames.get(basename(old_pdf))))

    # generate list of pages in form of images
    old_img_list = glob(g_old_path + "\\temp\\" + basename(old_pdf) + "_dir\\*.jpg")
    new_img_list = glob(g_new_path + "\\temp\\" + basename(new_pdf) + "_dir\\*.jpg")

    # extract text and cordinates pagewise from the pdf
    # oldpdf_pagewise_text, oldpdf_pagewise_cordinates = textandcordinates(old_pdf)
    # newpdf_pagewise_text, newpdf_pagewise_cordinates = textandcordinates(new_pdf)
    # since for now text extraction is on hold
    oldpdf_pagewise_text, oldpdf_pagewise_cordinates, newpdf_pagewise_text, newpdf_pagewise_cordinates = {}, {}, {}, {}

    notext = False
    if len(oldpdf_pagewise_text) == 0 or len(newpdf_pagewise_text) == 0:
        notext = True

    cache_function1 = extractdifference
    pagecount = 0
    for old_img, new_img in zip(old_img_list, new_img_list):
        if notext:
            cache_function1(old_img, new_img, old_pdf, [], [], [], [])
        else:
            cache_function1(old_img, new_img, old_pdf, oldpdf_pagewise_text[pagecount], \
                            oldpdf_pagewise_cordinates[pagecount], newpdf_pagewise_text[pagecount], \
                            newpdf_pagewise_cordinates[pagecount])
        pagecount += 1

    del oldpdf_pagewise_text, oldpdf_pagewise_cordinates, newpdf_pagewise_text, newpdf_pagewise_cordinates, notext, pagecount

    length_old_img_list = len(old_img_list)
    length_new_img_list = len(new_img_list)

    # if manual counting of pages is required
    global g_pagecount
    if g_coutpages:
        # set page count
        g_pagecount += length_old_img_list

    if length_old_img_list > length_new_img_list:
        excess_images = length_old_img_list - length_new_img_list
        # modify page count since old pdf has more pages
        if g_coutpages:
            g_pagecount = g_pagecount - excess_images
        #logging.info(str(excess_images) + " excess images found in file: {} and are hence not compared".format(
            #g_old_pdf_filenames.get(basename(old_pdf))))

    elif length_new_img_list > length_old_img_list:
        excess_images = length_new_img_list - length_old_img_list
        #logging.info(str(excess_images) + " excess images found in file: {} and are hence not compared".format(
            #g_new_pdf_filenames.get(basename(new_pdf))))

    del old_img_list, new_img_list, length_old_img_list, length_new_img_list

    makepdf(g_output_path + "\\" + g_old_pdf_filenames.get(basename(old_pdf)), old_pdf)

    rmtree(g_old_path + '\\temp')
    rmtree(g_new_path + '\\temp')

    #logging.info("Comparison complete for file\n")


def convertpdf(inputpath, outputpath):
    convert_pdf2jpg(inputpath, outputpath, pages="ALL")
    """ for executable
    jarPath = join(getcwd(), 'data', 'pdf2jpg.jar')
    cmd = 'java -Xmx1024m -jar "%s" -i "%s" -o "%s" -d %s -p %s' % (jarPath, inputpath, outputpath, str(300), "ALL")
    outputpdfdir = join(outputpath, basename(inputpath) + "_dir")
    if exists(outputpdfdir):
        rmtree(outputpdfdir)

    output = Popen(cmd, shell = True)
    output.wait()
    """


# This function is written to create a new directory
def cleanfolder(path, message):
    if isdir(path):
        rmtree(path)
        """
            after running rmtree to remake the directory we need to spend a CPU cycle for the register tables to refresh
            if we don't mkdir will throw an excpetion since the directory would still be present in the registers
        """
        sleep(.0000000000000001)

    mkdir(path)

    # set the new directory as hidden so that user does not open/delete directory during processing
    SetFileAttributes(path, win32con.FILE_ATTRIBUTE_HIDDEN)
    #logging.info(message)


# This function returns the total number of pages in a pdf document
def totalpages(pdf):
    numpages = 0
    with open(pdf, 'rb') as openfile:
        try:
            numpages = PdfFileReader(openfile).getNumPages()
        except:
            #logging.exception("PyPDF2")
            try:
                numpages = resolve1(PDFDocument(PDFParser(openfile)).catalog['Pages'])['Count']
            except:
                #logging.exception("PDFMiner")
                global g_coutpages
                g_coutpages = True
    return numpages


def maincode(input_email, old_path, new_path, calibration, output_path):
    global g_old_path
    global g_new_path
    global g_output_path
    global g_check_calibration

    g_old_path = old_path
    g_new_path = new_path
    g_output_path = output_path
    g_check_calibration = calibration

    # code to count the total number of pages that will be processed
    # check for NoOfUnits
    function1 = lambda pdftuple: min(totalpages(pdftuple[0]), totalpages(pdftuple[1]))
    NoOfUnits = sum(list(map(function1, zip(glob(g_old_path + "\\*.pdf"), glob(g_new_path + "\\*.pdf")))))

    # code to limit the usage to 300 pages
    # check_expiry = check_expiry_for_holds()
    check_expiry = 0  # since licensing is not reqired now

    if check_expiry > 300:
        #logging.info("License expired")
        pass
    elif check_expiry + NoOfUnits > 300:
        #logging.info("Your license allows to process {} pages of pdf files".format(str(300 - check_expiry)))
        pass
    else:
        StartDateTime = datetime.now()  # record StartDateTime when the module begins running
        try:
            # check if log folder already exists, if not make one
            if not isdir(getcwd() + "\\Logfiles for PDFSatya"):
                mkdir(getcwd() + "\\Logfiles for PDFSatya")

            # create logfile
            """
            logpath = getcwd() + "\\Logfiles for PDFSatya\\" + input_email.split('@')[0] + "_" + g_project.title() + "_" + StartDateTime.strftime(
                "%H_%M") + ".log"
            logformat = "%(lineno)s \t %(funcName)s \t %(asctime)s \t %(message)s"
            for handler in logging.root.handlers[:]:
                logging.root.removeHandler(handler)
            logging.basicConfig(filename=logpath, filemode='w', level=logging.DEBUG, format=logformat)

            logging.getLogger('pdfminer').setLevel(logging.ERROR)

            logging.info("\n")
            logging.info("---------------------Starting Program execution---------------------")
            logging.info("\n")

            # log the selected old and new paths
            logging.info("Old files path: {}".format(g_old_path))
            logging.info("New files path: {}".format(g_new_path))
            logging.info("\n")
            """

            # create temporary path for processing files
            global g_processing_path
            g_processing_path = g_output_path + "\\processing"
            cleanfolder(g_processing_path, "Processing folder created\n")

            """
            if g_check_calibration == -1:
                logging.info("Manual calibration is selected")
            elif g_check_calibration == 1:
                logging.info("Automatic calibration is selected")
            else:
                logging.info("No calibration is selected")
            logging.info("\n")
            """

            # copy all files to processing folder within thier respective paths and
            # rename all files to avoid windows'/cv2 errors when saving large filenames
            # also record all filenames in dictionaries to use actual names during processing and logging
            old_path_processing = g_old_path + "\\processing_{}".format(StartDateTime.strftime("%H %M"))
            new_path_processing = g_new_path + "\\processing_{}".format(StartDateTime.strftime("%H %M"))

            # make directory within old_path to copy pdfs
            cleanfolder(old_path_processing, "Processing folder created for old_path\n")

            # make directory within new_path to copy pdfs
            cleanfolder(new_path_processing, "Processing folder created for new_path\n")

            global g_old_pdf_filenames
            global g_new_pdf_filenames
            counter = 1
            for old_pdf, new_pdf in zip(glob(g_old_path + "\\*.pdf"), glob(g_new_path + "\\*.pdf")):
                newfilename_old_pdf = old_path_processing + "\\old_{}_{}.pdf".format(counter,
                                                                                     StartDateTime.strftime("%H %M"))
                newfilename_new_pdf = new_path_processing + "\\new_{}_{}.pdf".format(counter,
                                                                                     StartDateTime.strftime("%H %M"))

                copy(old_pdf, newfilename_old_pdf)
                copy(new_pdf, newfilename_new_pdf)

                g_old_pdf_filenames[basename(newfilename_old_pdf)] = basename(old_pdf)
                g_new_pdf_filenames[basename(newfilename_new_pdf)] = basename(new_pdf)
                counter += 1

                #logging.info("{} copied and renamed to {}".format(basename(old_pdf), basename(newfilename_old_pdf)))
                #logging.info("{} copied and renamed to {}".format(basename(new_pdf), basename(newfilename_new_pdf)))
                #logging.info("\n")

                del newfilename_old_pdf, newfilename_new_pdf

            g_old_path = old_path_processing
            g_new_path = new_path_processing

            del old_path_processing, new_path_processing

            pdf_list = tuple(zip(glob(g_old_path + "\\*.pdf"), glob(g_new_path + "\\*.pdf")))

            old_path_temp = g_old_path + "\\temp"
            new_path_temp = g_new_path + "\\temp"

            # make directory within old_path to save pdf to jpg output
            cleanfolder(old_path_temp, "Temporary folder created for old_path\n")

            # make directory within new_path to save pdf to jpg output
            cleanfolder(new_path_temp, "Temporary folder created for new_path\n")

            # cache the functions for optimization in for loop
            cache_function1 = convertpdf
            cache_function2 = compare

            for old_pdf, new_pdf in pdf_list:
                # convert pdf's to images
                cache_function1(old_pdf, old_path_temp)
                #logging.info(g_old_pdf_filenames.get(basename(old_pdf)) + " was converted to jpg")
                cache_function1(new_pdf, new_path_temp)
                #logging.info(g_new_pdf_filenames.get(basename(new_pdf)) + " was converted to jpg")

                # compare the files
                cache_function2(old_pdf, new_pdf)

                # force garbage collection to theoritically remove all unused objects
                gc.collect()

            rmtree(g_processing_path)
            rmtree(g_old_path)
            rmtree(g_new_path)

            EndDateTime = datetime.now()
            #logging.info("Program started at: " + StartDateTime.strftime("%H_%M_%S"))
            #logging.info("Program ended at: " + EndDateTime.strftime("%H_%M_%S"))
            #logging.info(str(len(pdf_list)) + " files processed")

            #logging.info("\n")
            #logging.info("---------------------Program successfully executed---------------------")

            if g_coutpages:
                NoOfUnits = g_pagecount

        # add_units_locking(NoOfUnits)

        except:
            global g_error_present
            g_error_present = True

            try:
                rmtree(g_processing_path)
            except:
                pass
            try:
                rmtree(old_path_processing)
            except:
                pass
            try:
                rmtree(new_path_processing)
            except:
                pass

            #logging.error("\n")
            #logging.exception("Exception\n")
            #logging.error("\n")

        if g_error_present:
            Status = "Failed"
        else:
            Status = "Completed"

        #logging.info("\n")
        # create SQL entry
        #logging.info('Fetching the logged in user')
        LoggedInUser = input_email.split('@')[0]
        #logging.info('Fetching the machine name')
        MachineName = gethostname()
        #logging.info('Fetching the country and location')
        Country, Location, _ = get_mail_country_and_location(input_email)
        mail = input_email
        EndDateTime = datetime.now()

        
        #logging.info('Storing the execution log in database')
        storing_in_db_worley(g_project.title(),StartDateTime,EndDateTime,Status,
                LoggedInUser,MachineName,Country,Location,"DATA SCIENCE",str(NoOfUnits))


        # beautify logfile by removing built in module logs
        """
        with open(logpath, "r+") as f:
            lines = f.readlines()
            f.seek(0)
            for line in lines:
                if ("maincode" in line) or ("totalpages" in line) or ("cleanfolder" in line) \
                        or ("compare" in line) or ("manualcalibrate" in line) or ("autocalibrate" in line) \
                        or ("highlighttext" in line) or ("\n" in line) and ("init" not in line):
                    f.write(line)
            f.truncate()
        """

        """
        try:
            sendmail(logpath)
        except:
            logging.exception("Sendmail exception")
        """

"""
if exists(getcwd() + '\\data\\pdf2jpg.jar'):
    maincode(input_email, old_path, new_path, calibration, output_path)
else:
    logging.info("Files required for execution are missing")
"""