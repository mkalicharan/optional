from PIL import Image
import cv2
from numpy import asarray
from pytesseract import image_to_osd
from re import search

""" module written to align 2 images """

"""
# convert PIL image to opencv
opencv_image = np.asarray(PIL_image)
opencv_image = cv2.cvtColor(opencv_image, cv2.COLOR_RGB2BGR)

# convert opencv image to PIL
opencv_image = cv2.cvtColor(opencv_image, cv2.COLOR_BGR2RGB)
PIL_image = Image.fromarray(opencv_image)
"""

def rotate(image):
    angle = 0
    try:
	    angle = 360-int(search('(?<=Rotate: )\\d+', image_to_osd(image)).group(0))
	    
	    if angle == 270:
	    	image = cv2.rotate(image, cv2.ROTATE_90_COUNTERCLOCKWISE)

	    if angle == 180:
	    	image = cv2.rotate(image, cv2.ROTATE_180)

	    if angle == 90:
	    	image = cv2.rotate(image, cv2.ROTATE_90_CLOCKWISE)

    except:
    	pass
    finally:
    	return image, angle


def auto_orient(image1, image2):
	# image1 will be considered as the base image
	# image1's orientation is corrected based on text within image
	# image1, angle1 = rotate(image1)

	# convert the colors for PIL
	image1_rgb = cv2.cvtColor(image1, cv2.COLOR_BGR2RGB)
	image2_rgb = cv2.cvtColor(image2, cv2.COLOR_BGR2RGB)

	PIL_image1 = Image.fromarray(image1_rgb)
	PIL_image2 = Image.fromarray(image2_rgb)

	w1, h1 = PIL_image1.size
	w2, h2 = PIL_image2.size

	#newW = max(w1, w2)
	#newH = max(h1, h2)
	newW = newH = max(w1, h1, w2, h2)

	# create a new padded image for perfect template matching
	# since max of all dimensions has been considered, template and base image will always have the same size
	template_img1 = Image.new('RGB', (newW, newH), (255,255,255))
	template_img2 = Image.new('RGB', (newW, newH), (255,255,255))

	image1_xoffset = int((newW - w1)/2)
	image1_yoffset = int((newH - h1)/2)

	template_img1.paste(PIL_image1, (image1_xoffset, image1_yoffset))

	del image1_xoffset, image1_yoffset, w1, h1

	image2_xoffset = int((newW - w2)/2)
	image2_yoffset = int((newH - h2)/2)

	template_img2.paste(PIL_image2, (image2_xoffset, image2_yoffset))

	del PIL_image1, PIL_image2, image2_xoffset, image2_yoffset, w2, h2, newW, newH

	# convert template images to cv2 and convert to gray for template matching
	cv2_template_image1 = asarray(template_img1)
	cv2_template_image1 = cv2.cvtColor(cv2_template_image1, cv2.COLOR_RGB2BGR)
	cv2_template_image1 = cv2.cvtColor(cv2_template_image1, cv2.COLOR_BGR2GRAY)
	
	cv2_template_image2 = asarray(template_img2)
	cv2_template_image2 = cv2.cvtColor(cv2_template_image2, cv2.COLOR_RGB2BGR)
	cv2_template_image2 = cv2.cvtColor(cv2_template_image2, cv2.COLOR_BGR2GRAY)

	del template_img1, template_img2

	# image 2 is rotated by all 4 angles and matched with image 1
	image2_allangles = [cv2_template_image2]

	# rotated by 90
	image2_allangles.append(cv2.rotate(cv2_template_image2, cv2.ROTATE_90_CLOCKWISE))

	# rotated by 180
	image2_allangles.append(cv2.rotate(cv2_template_image2, cv2.ROTATE_180))

	# rotated by 90 counterclockwise
	image2_allangles.append(cv2.rotate(cv2_template_image2, cv2.ROTATE_90_COUNTERCLOCKWISE))

	# set current confidence as 0
	current_confidence = 0
	angle2=0
	counter = 0
	for i in range(4):
		# Perform match operations.
		res = cv2.matchTemplate(cv2_template_image1, image2_allangles[i], cv2.TM_CCOEFF_NORMED)
		_, confidence, _, _ = cv2.minMaxLoc(res)
		# compare confidence
		if confidence > current_confidence:
			# rotate the image based on the confidence
			if i == 0:
				image2_rotated = image2
				angle2 = 90
			elif i == 1:
				image2_rotated = cv2.rotate(image2, cv2.ROTATE_90_CLOCKWISE)
				angle2 = 90
			elif i == 2:
				image2_rotated = cv2.rotate(image2, cv2.ROTATE_180)
				angle2 = 90
			elif i == 3:
				image2_rotated = cv2.rotate(image2, cv2.ROTATE_90_COUNTERCLOCKWISE)
				angle2 = 90		
			# update confidence
			current_confidence = confidence
	
	return image1, image2_rotated, angle2