function get_ext(filename)
{
    return filename.split('.').pop()
}

function validate_email()
{
    var email = document.getElementById("input_email")
    var submitbutton = document.getElementById("submitbutton")

    var regtest1 = /^([A-Za-z0-9])+\.([A-Za-z0-9])+\@(worleyparsons.com)$/;
    var regtest2 = /^([A-Za-z0-9])+\.([A-Za-z0-9])+\@(WorleyParsons.com)$/;
    var regtest3 = /^([A-Za-z0-9])+\.([A-Za-z0-9])+\@(worley.com)$/;
    var regtest4 = /^([A-Za-z0-9])+\.([A-Za-z0-9])+\@(Worley.com)$/;

    if (regtest1.test(email.value) == false && regtest2.test(email.value) == false && regtest3.test(email.value) == false && regtest4.test(email.value) == false) 
    {
        submitbutton.disabled = true;
        submitbutton.value = 'Please enter the correct email address'
    }

    else
    {
        submitbutton.disabled = false;
        submitbutton.value = 'Submit'
    }
}

function selectnc()
{
    document.getElementById("calibrationlabel").innerHTML = 'No Calibration Selected'
    submitbutton.disabled = false;
    submitbutton.value = 'Submit'
}

function selectac()
{
    document.getElementById("calibrationlabel").innerHTML = 'Automatic Calibration Selected'
    submitbutton.disabled = false;
    submitbutton.value = 'Submit'
}

function upload_on_change_old()
{
    var inputfiles = document.getElementById("input_files_old")
    var files = inputfiles.files;
    var file;
    var flag;

    for (var i = 0; i < files.length; i++){
        filename = files.item(i).name;
        if(get_ext(filename).toLowerCase() != 'pdf'){
                flag = 1;
                break;
        }
        else{
            flag = 0
        }
    }

    if(flag == 1){
            file_error_old.style.display = 'block';
            submitbutton.disabled = true;
            submitbutton.value = 'Choose & Upload PDF Type only in OLD pdf'
            input_files_old.focus()
            return false;
        }
    else {
            file_error_old.style.display = 'none';
            submitbutton.disabled = false;
            submitbutton.value = 'Submit'
            return true;
    }
}

function upload_on_change_new(){
    var inputfiles = document.getElementById("input_files_new")
    var files = inputfiles.files;
    var file;
    var flag;

    for (var i = 0; i < files.length; i++){
        filename = files.item(i).name;
        if(get_ext(filename).toLowerCase() != 'pdf'){
                flag = 1;
                break;
        }
        else {
            flag = 0
        }
    }

    if(flag == 1){
            file_error_new.style.display = 'block';
            submitbutton.disabled = true;
            submitbutton.value = 'Choose & Upload PDF Type only in NEW pdf'
            input_files_new.focus();
            return false;
        }
    else {
            file_error_new.style.display = 'none';
            submitbutton.disabled = false;
            submitbutton.value = 'Submit'
            return true;
    }
}

function validate_file(){

    if (!document.getElementById("ncbutton").checked && !document.getElementById("acbutton").checked)
    {
        submitbutton.disabled = true
        submitbutton.value = 'Please select a mode of Calibration'
        return false
    }

    old_file_status = upload_on_change_old()
    new_file_status = upload_on_change_new()
    var flag = 0;
    if (old_file_status == true && new_file_status == true){
        flag = flag + 2
    }

    if (flag == 2){
        form_display.style.display = 'none';
        restart_display.style.display = 'block';
        var restartHelp = document.getElementById("Restart_help");
        restartHelp.innerHTML = "<span style='color: red;'>After Execution you will be directed to save your file, or it will be downloaded automatically<br><b> DO NOT CLOSE THE WINDOW BEFORE THE DOWNLOAD COMPLETES</b></span>";
        return true
    }
    else{
        if (old_file_status == false) {
                file_error_old.style.display = 'block';
                submitbutton.disabled = true;
                submitbutton.value = 'Choose & Upload PDF Type only in OLD pdf'
                input_files_old.focus()
                return false;}
        if (new_file_status == false) {
                file_error_old.style.display = 'block';
                submitbutton.disabled = true;
                submitbutton.value = 'Choose & Upload PDF Type only in OLD pdf'
                input_files_old.focus()
                return false;}
            return false
    }
}