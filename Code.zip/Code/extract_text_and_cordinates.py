import pdfminer
from pdfminer.pdfparser import PDFParser
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdfpage import PDFPage, PDFTextExtractionNotAllowed
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfdevice import PDFDevice
from pdfminer.layout import LAParams
from pdfminer.converter import PDFPageAggregator
import logging


""" module written to extract text and corresponding cordinates from pdf file """

special_chars = ['`', '~', '@', '#', '$', '%', '^', '&',
                 '*', '(', ')', '_', '-', '=', '+', '{',
                 '[', '}', ']', '\\', '|', '"', "'", ':',
                 ';', '<', ',', '>', '.', '/', '?', ' ']


def preprocess(text):
    text = text.replace('\n', '').strip().lower()
    for character in special_chars:
        text = text.replace(character, '')
    return text


def parse_obj(lt_objs, pagesize):
    
    # pagewidth = x2 - x1
    # pageheight = y2 - y1
    pagewidth = pagesize[2] - pagesize[0]
    pageheight = pagesize[3] - pagesize[1]

    textinpage = []
    textcordinates = []
    
    # loop over the object list
    for obj in lt_objs:

        # if it's a textbox, print text and location
        if isinstance(obj, pdfminer.layout.LTTextBoxHorizontal):
            textinpage.append(preprocess(obj.get_text()))
            startX, startY, endX, endY = obj.bbox[0], obj.bbox[1], obj.bbox[2], obj.bbox[3]
            
            """ to scale according to image
                image_x = pdf_x * image_width / pdfpage_width
                image_y = (pdfpage_height - pdf_y) * image_height / pdfpage_height
            """

            # points adjusted according to page size
            startX = startX / pagewidth
            startY = (pageheight - startY) / pageheight
            endX = endX / pagewidth
            endY = (pageheight - endY) / pageheight
            
            textcordinates.append([startX, startY, endX, endY])

        # if it's a container, recurse
        elif isinstance(obj, pdfminer.layout.LTFigure):
            text, cordinates = parse_obj(obj._objs, pagesize)
            textinpage.extend(text)
            textcordinates.extend(cordinates)

    return textinpage, textcordinates


def textandcordinates(filepath):
    
    logging.getLogger('pdfminer').setLevel(logging.ERROR)

    try:
        # Open a PDF file.
        file = open(filepath, 'rb')

        # Create a PDF parser object associated with the file object.
        parser = PDFParser(file)

        # Create a PDF document object that stores the document structure.
        # Password for initialization as 2nd parameter
        document = PDFDocument(parser)

        # Check if the document allows text extraction. If not, abort.
        if not document.is_extractable:
            file.close()
            return [], []
            #raise PDFTextExtractionNotAllowed

        # Create a PDF resource manager object that stores shared resources.
        rsrcmgr = PDFResourceManager()

        # Create a PDF device object.
        device = PDFDevice(rsrcmgr)

        # BEGIN LAYOUT ANALYSIS
        # Set parameters for analysis.
        laparams = LAParams()

        # Create a PDF page aggregator object.
        device = PDFPageAggregator(rsrcmgr, laparams=laparams)

        # Create a PDF interpreter object.
        interpreter = PDFPageInterpreter(rsrcmgr, device)

        pagewise_text = {}
        pagewise_cordinates = {}
        pagecounter = 0

        # loop over all pages in the document
        for page in PDFPage.create_pages(document):

            # read the page into a layout object
            interpreter.process_page(page)
            layout = device.get_result()

            # get page size
            pagesize = page.mediabox

            # extract text from this object
            textinpage, textcordinates = parse_obj(layout._objs, pagesize)
            
            pagewise_text[pagecounter] = textinpage
            pagewise_cordinates[pagecounter] = textcordinates

            pagecounter += 1

        file.close()

        return pagewise_text, pagewise_cordinates

    except:
        return {}, {}