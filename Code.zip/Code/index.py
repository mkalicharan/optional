from waitress import serve
from webbrowser import open_new_tab
from flask import Flask, send_file, request, redirect, render_template
from os import getcwd, makedirs, listdir
from os.path import basename, join, exists
from shutil import rmtree
from werkzeug.utils import secure_filename
from pdfcompare_v4 import maincode
from zipfile import ZipFile
from glob import glob
from time import sleep
from ldap3 import Server, Connection, ALL
import multiprocessing


# variable to control chance of credential check
check = False

def checkcredentials(input_email):
    global check
    while check:
        pass
    # aquire lock
    check = True
    try:
        host, user, password = 'LDAP://WorleyParsons.com', 'automation.anywhere', 'Auto@AnyIndia99'
        searchfilter = '(sAMAccountName=' + input_email.split('@')[0] + ')'

        server = Server(host, get_info=ALL)
        conn = Connection(server, user, password, auto_bind=True, check_names=True)
        conn.search('dc=WorleyParsons,dc=com', searchfilter, attributes=['co', 'displayName', 'mail'])

        if len(conn.entries) > 0:
            # release lock
            check = False
            return True
        else:
            # release lock
            check = False
            return False

    except:
        # if user is not in Worley's domain, check in Jacobs' domain
        try:
            host, user, password = 'ldap.europe.jacobs.com', r'JEGINTL\injbot001', '3hYN##dP@$sw0rd'
            searchfilter = '(mail=' + input_email + ')'

            server = Server(host, get_info=ALL)
            conn = Connection(server, user, password, auto_bind=True)
            conn.search('dc=europe,dc=jacobs,dc=com', searchfilter, attributes=['co', 'displayName', 'mail'])

            if len(conn.entries) > 0:
                # release lock
                check = False
                return True
            else:
                # release lock
                check = False
                return False

        except:
            return False


def runsatya(input_email, old_path, new_path, calibration, output_path):
    maincode(input_email, old_path, new_path, calibration, output_path)

    if len(listdir(output_path)) > 1:
        # create a zip file of all output pdfs
        zipObj = ZipFile(output_path + '{}_output.zip'.format(input_email.split('@')[0]), 'w')

        for filepath in glob(output_path + '*.pdf'):
            zipObj.write(filepath, basename(filepath))

        # close the Zip File
        zipObj.close()


app = Flask(__name__)
app.secret_key = "secret key"


@app.route('/')
def index():
    return redirect('http://sgazrdevapp14v.worleyparsons.com:7003/pdfsatya')


@app.route('/pdfsatya')
def upload_form():
    return render_template('layout.html')


@app.route('/result', methods=['POST', 'GET'])
def result():
    input_email = request.form['Email']
    if checkcredentials(input_email):
        file_upload_folder = getcwd() + '/' + input_email + '/'

        if request.form['calibutton'] == "ac":
            calibration = 1
        else:
            calibration = 0

        if exists(file_upload_folder):
            rmtree(getcwd() + '/' + input_email)
            sleep(0.000001)

        old_path = file_upload_folder + 'old/'
        new_path = file_upload_folder + 'new/'
        output_path = file_upload_folder + 'output/'

        makedirs(file_upload_folder)
        makedirs(old_path)
        makedirs(new_path)
        makedirs(output_path)
        makedirs(output_path + '/processing')

        if request.method == 'POST':
            if 'old_files[]' not in request.files:
                return redirect(request.url)
            for file in request.files.getlist('old_files[]'):
                filename = secure_filename(file.filename)
                file.save(join(old_path, filename))

        if request.method == 'POST':
            if 'new_files[]' not in request.files:
                return redirect(request.url)
            for file in request.files.getlist('new_files[]'):
                filename = secure_filename(file.filename)
                file.save(join(new_path, filename))

        if request.method == 'POST':
            process = multiprocessing.Process(target=runsatya, args=(input_email, old_path, new_path, calibration, output_path))
            process.start()
            process.join()

            if len(listdir(output_path)) == 1:
                download = output_path + listdir(output_path)[0]

            else:
                download = output_path + '{}_output.zip'.format(input_email.split('@')[0])

        return send_file(download, as_attachment=True)

    else:
        return render_template('invalidcredentials.html')


if __name__ == "__main__":
    # open_new_tab('http://localhost:7003/pdfsatya')
    # app.run(host="10.50.48.55", port=7003, threaded=True, debug=True)
    serve(app, host="10.50.48.55", port=7003, url_scheme='https', threads=3)
