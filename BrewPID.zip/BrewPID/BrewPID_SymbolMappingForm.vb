﻿Imports System.IO

Public Class BrewPID_SymbolMappingForm

    Public Shared Pipelines_In_DataGrid As List(Of String) = New List(Of String)
    Public Shared Components_In_DataGrid As List(Of String) = New List(Of String)

    ''' <summary>
    ''' 'Component_DataGrid_CellContentClick' subprocess defines what happens after the 3rd row buttons of Component_DataGrid (to browse the symbol locations) are pressed
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Component_DataGrid_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles Component_DataGrid.CellContentClick
        Try
            'Display the entry chosen by the user using OpenFileDialog_2 in the 2nd row of Component_DataGrid
            If OpenFileDialog_2.ShowDialog = DialogResult.OK Then
                Component_DataGrid.Rows(e.RowIndex).Cells(1).Value = OpenFileDialog_2.FileName
            End If
        Catch ex As Exception
            WriteLog("Error in 'Component_DataGrid_CellContentClick' subprocess : " + ex.Message)
            PropStreamWriterObject.Close()
            BrewPID_MainForm.Close()
        End Try

    End Sub

    ''' <summary>
    ''' 'Submit_Button_Click' subprocess defines what happens after Submit_Button is clicked in Form2
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Submit_Button_Click(sender As Object, e As EventArgs) Handles Submit_Button.Click
        Try
            Dim mapping_file_new As New List(Of String)
            Dim mapping_file_symbols As New List(Of String)
            For datagrid_row_index = 0 To (Component_DataGrid.Rows.Count - 1)
                'Check whether either of the necessary entries in the datagrid is empty, do not proceed in recording it if that is the case
                If Not ((String.IsNullOrWhiteSpace(Component_DataGrid.Rows(datagrid_row_index).Cells(0).Value)) Or (String.IsNullOrWhiteSpace(Component_DataGrid.Rows(datagrid_row_index).Cells(1).Value)) Or (String.IsNullOrWhiteSpace(Component_DataGrid.Rows(datagrid_row_index).Cells(3).Value))) Then
                    'Add "Component_Name, Component Path, Component Type" for every component from the Component_DataGrid to the mapping_file_new list
                    mapping_file_new.Add(Component_DataGrid.Rows(datagrid_row_index).Cells(0).Value & "," & Component_DataGrid.Rows(datagrid_row_index).Cells(1).Value & "," & Component_DataGrid.Rows(datagrid_row_index).Cells(3).Value)
                    mapping_file_symbols.Add(Component_DataGrid.Rows(datagrid_row_index).Cells(0).Value)
                    'Check if the 'Component File' tab or 'Pipeline_File' tab is selected
                    If BrewPID_MainForm.TabControl_BrewPID.SelectedIndex = 0 Then
                        Components_In_DataGrid.Add(Component_DataGrid.Rows(datagrid_row_index).Cells(0).Value)
                    Else
                        Pipelines_In_DataGrid.Add(Component_DataGrid.Rows(datagrid_row_index).Cells(0).Value)
                    End If
                End If
            Next

            'Check if 'Component File' Tab or some other tab is selected in BrewPID_MainForm
            If BrewPID_MainForm.TabControl_BrewPID.SelectedIndex = 0 Then
                'Call the GenerateNewMasterMappingCSV subprocess
                GenerateNewMasterMappingCSV(BrewPID_MainForm.Component_Text_Path.Text, mapping_file_new, mapping_file_symbols)
            Else
                'Call the GenerateNewMasterMappingCSV subprocess
                GenerateNewMasterMappingCSV(BrewPID_MainForm.Pipeline_Text_Path.Text, mapping_file_new, mapping_file_symbols)
            End If
            'Me.Hide()
            Hide()
        Catch ex As Exception
            WriteLog("Error in 'Submit_Button_Click' subprocess : " + ex.Message)
            PropStreamWriterObject.Close()
            BrewPID_MainForm.Close()
        End Try
    End Sub

    ''' <summary>
    ''' 'GenerateNewMasterMappingCSV' subprocess generates a new master mapping file based on the input mapping_file_symbols
    ''' </summary>
    ''' <param name="File_Path"></param>
    ''' <param name="mapping_file_new"></param>
    ''' <param name="mapping_file_symbols"></param>
    Private Sub GenerateNewMasterMappingCSV(File_Path, mapping_file_new, mapping_file_symbols)
        Try
            'Check if the Master_mapping.csv is empty or not
            If File.ReadAllText(Path.GetDirectoryName(File_Path) + "\Master_Mapping.csv").Length <> 0 Then
                'Convert the Master_Mapping.csv to a list
                Dim master_mapping_list As List(Of String) = File.ReadAllLines(Path.GetDirectoryName(File_Path) + "\Master_Mapping.csv").ToList()
                'Iterate through each row of the master_mapping_list and, add the symbol only in the mapping_file_symbols list and the symbol along with its path and type, in case the symbol is not already present in the master_mapping_list
                For Each row_present In master_mapping_list
                    If Not mapping_file_symbols.Contains(row_present.Split(",")(0)) Then
                        mapping_file_new.Add(row_present.Split(",")(0) & "," & row_present.Split(",")(1) & "," & row_present.Split(",")(2))
                        mapping_file_symbols.Add(row_present.Split(",")(0))
                    End If
                Next
            End If
            'Write the new Master Mapping file
            File.WriteAllLines(Path.GetDirectoryName(File_Path) + "\Master_Mapping.csv", mapping_file_new.ToArray())
        Catch ex As Exception
            WriteLog("Error in 'GenerateNewMasterMappingCSV' subprocess : " + ex.Message)
            PropStreamWriterObject.Close()
            BrewPID_MainForm.Close()
        End Try

    End Sub

    ''' <summary>
    ''' 'Remove_Symbol_Button_Click' subprocess defines what happens when the Remove_Symbol_Button in the BrewPID_SymbolMappingForm is clicked
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Remove_Symbol_Button_Click(sender As Object, e As EventArgs) Handles Remove_Symbol_Button.Click
        Try
            'Remove the rows of Components_DataGrid whcih have been selected by the user
            For Each row As DataGridViewRow In Component_DataGrid.SelectedRows
                Component_DataGrid.Rows.Remove(row)
            Next
        Catch ex As Exception
            WriteLog("Error in 'Remove_Symbol_Button_Click' subprocess : " + ex.Message)
            PropStreamWriterObject.Close()
            BrewPID_MainForm.Close()
        End Try
    End Sub

    ''' <summary>
    ''' 'Add_Symbol_Button_Click' subprocess defines what happens when the Add_Symbol_Button in the BrewPID_SymbolMappingForm is clicked
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Add_Symbol_Button_Click(sender As Object, e As EventArgs) Handles Add_Symbol_Button.Click
        Try
            'Add an empty row in the Component_DataGrid
            Dim row As ArrayList = New ArrayList
            row.Add(String.Empty)
            row.Add(String.Empty)
            row.Add("...")
            row.Add(String.Empty)
            Component_DataGrid.Rows.Add(row.ToArray())
        Catch ex As Exception
            WriteLog("Error in 'Add_Symbol_Button_Click' subprocess : " + ex.Message)
            PropStreamWriterObject.Close()
            BrewPID_MainForm.Close()
        End Try
    End Sub

    ''' <summary>
    ''' 'Component_Datagrid_CurrentCellDirtyStateChanged' subprocess defines what happens when the dirty state of the Component_Datagrid's Current Cell is changed
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Component_Datagrid_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles Component_DataGrid.CurrentCellDirtyStateChanged
        Try
            'Check if the Current cell belongs to Column is and is dirty
            If ((Component_DataGrid.IsCurrentCellDirty) And (Component_DataGrid.CurrentCell.ColumnIndex = 0)) Then
                Component_DataGrid.CommitEdit(DataGridViewDataErrorContexts.Commit)
                'Add all the component names of all the rows (except the current row) of the Component_dataGrid to the current_components_in_datagrid list
                Dim current_components_in_datagrid As List(Of String) = New List(Of String)
                If Component_DataGrid.Rows.Count > 1 Then
                    For datagrid_row_index = 0 To (Component_DataGrid.Rows.Count - 1)
                        If datagrid_row_index <> Component_DataGrid.CurrentCell.RowIndex Then
                            current_components_in_datagrid.Add(Component_DataGrid.Rows(datagrid_row_index).Cells(0).Value)
                        End If
                    Next
                End If
                'Check if the user adds a symbol present in the current_components_in_datagrid list and prompt him regarding the same if that is the case and then clear the data from that row
                If current_components_in_datagrid.Contains(Component_DataGrid.CurrentCell.Value) Then
                    MessageBox.Show("The symbol '" + Component_DataGrid.CurrentCell.Value + "' has already been added in the table.")
                    Component_DataGrid.Rows.RemoveAt(Component_DataGrid.CurrentCell.RowIndex)
                    'Add an empty row in the Component_DataGrid
                    Dim row As ArrayList = New ArrayList
                    row.Add(String.Empty)
                    row.Add(String.Empty)
                    row.Add("...")
                    row.Add(String.Empty)
                    Component_DataGrid.Rows.Add(row.ToArray())
                    'Check whether the symbol added by the user is already present in the components_in_MasterMapping list of BrewPID_MainForm, and give the proper Symbol type and Symbol location in case it does
                ElseIf BrewPID_MainForm.components_in_MasterMapping.ContainsKey(Component_DataGrid.CurrentCell.Value) Then
                    Component_DataGrid.Rows(Component_DataGrid.CurrentCell.RowIndex).Cells(1).Value = BrewPID_MainForm.components_in_MasterMapping(Component_DataGrid.CurrentCell.Value).Split(",")(0)
                    Component_DataGrid.Rows(Component_DataGrid.CurrentCell.RowIndex).Cells(3).Value = BrewPID_MainForm.components_in_MasterMapping(Component_DataGrid.CurrentCell.Value).Split(",")(1)
                End If
            End If
        Catch ex As Exception
            WriteLog("Error in 'Component_Datagrid_CurrentCellDirtyStateChanged' subprocess : " + ex.Message)
            PropStreamWriterObject.Close()
            BrewPID_MainForm.Close()
        End Try
    End Sub

End Class