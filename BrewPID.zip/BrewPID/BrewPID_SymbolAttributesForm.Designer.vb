﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BrewPID_SymbolAttributesForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BrewPID_SymbolAttributesForm))
        Me.Symbol_Attribute_Datagrid = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Button_Add_Atrribute = New System.Windows.Forms.Button()
        Me.Button_Submit = New System.Windows.Forms.Button()
        Me.Button_Remove_Attribute = New System.Windows.Forms.Button()
        CType(Me.Symbol_Attribute_Datagrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Symbol_Attribute_Datagrid
        '
        Me.Symbol_Attribute_Datagrid.AllowUserToAddRows = False
        Me.Symbol_Attribute_Datagrid.AllowUserToDeleteRows = False
        Me.Symbol_Attribute_Datagrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Symbol_Attribute_Datagrid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2})
        Me.Symbol_Attribute_Datagrid.Location = New System.Drawing.Point(12, 12)
        Me.Symbol_Attribute_Datagrid.Name = "Symbol_Attribute_Datagrid"
        Me.Symbol_Attribute_Datagrid.Size = New System.Drawing.Size(807, 187)
        Me.Symbol_Attribute_Datagrid.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.HeaderText = "Attribute Number"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Column1.Width = 110
        '
        'Column2
        '
        Me.Column2.HeaderText = "                                                                              Att" &
    "ribute Name"
        Me.Column2.Name = "Column2"
        Me.Column2.Width = 650
        '
        'Button_Add_Atrribute
        '
        Me.Button_Add_Atrribute.Location = New System.Drawing.Point(12, 215)
        Me.Button_Add_Atrribute.Name = "Button_Add_Atrribute"
        Me.Button_Add_Atrribute.Size = New System.Drawing.Size(93, 23)
        Me.Button_Add_Atrribute.TabIndex = 1
        Me.Button_Add_Atrribute.Text = "  Add Attribute"
        Me.Button_Add_Atrribute.UseVisualStyleBackColor = True
        '
        'Button_Submit
        '
        Me.Button_Submit.Location = New System.Drawing.Point(726, 215)
        Me.Button_Submit.Name = "Button_Submit"
        Me.Button_Submit.Size = New System.Drawing.Size(93, 23)
        Me.Button_Submit.TabIndex = 2
        Me.Button_Submit.Text = "Submit"
        Me.Button_Submit.UseVisualStyleBackColor = True
        '
        'Button_Remove_Attribute
        '
        Me.Button_Remove_Attribute.Location = New System.Drawing.Point(133, 215)
        Me.Button_Remove_Attribute.Name = "Button_Remove_Attribute"
        Me.Button_Remove_Attribute.Size = New System.Drawing.Size(104, 23)
        Me.Button_Remove_Attribute.TabIndex = 3
        Me.Button_Remove_Attribute.Text = "Remove Attribute"
        Me.Button_Remove_Attribute.UseVisualStyleBackColor = True
        '
        'BrewPID_SymbolAttributesForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(831, 261)
        Me.Controls.Add(Me.Button_Remove_Attribute)
        Me.Controls.Add(Me.Button_Submit)
        Me.Controls.Add(Me.Button_Add_Atrribute)
        Me.Controls.Add(Me.Symbol_Attribute_Datagrid)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "BrewPID_SymbolAttributesForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Symbol Attributes"
        CType(Me.Symbol_Attribute_Datagrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Symbol_Attribute_Datagrid As DataGridView
    Friend WithEvents Button_Add_Atrribute As Button
    Friend WithEvents Button_Submit As Button
    Friend WithEvents Button_Remove_Attribute As Button
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewComboBoxColumn
End Class
