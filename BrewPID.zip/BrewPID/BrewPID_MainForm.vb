﻿Imports System.IO
Imports System.Runtime.InteropServices

Public Class BrewPID_MainForm

    Dim component_columns As List(Of String)
    Dim pipeline_columns As List(Of String)
    Public components_in_MasterMapping As Dictionary(Of String, String)

    ''' <summary>
    ''' 'add_to_datagrid' subprocess adds rows to the Component_DataGrid in Form BrewPID_SymbolMappingForm based upon the entries in the Master mapping File and the new entries in the CSV
    ''' </summary>
    ''' <param name="name_list"></param>
    ''' <param name="File_Path"></param>
    Public Sub add_to_datagrid(name_list, File_Path)
        Try
            'Clear the rows of the datagrid so that user can enter the rows freshly
            BrewPID_SymbolMappingForm.Component_DataGrid.Rows.Clear()
            BrewPID_SymbolMappingForm.Component_DataGrid.Refresh()
            Dim mapping_file As List(Of String)
            BrewPID_SymbolMappingForm.Column1.Items.Clear()
            components_in_MasterMapping = New Dictionary(Of String, String)
            'Check if content in Master Mapping file is finite in length
            If File.ReadAllText(Path.GetDirectoryName(File_Path.Text) + "\Master_Mapping.csv").Length <> 0 Then
                'Read all lines of Master Mapping file
                mapping_file = File.ReadAllLines(Path.GetDirectoryName(File_Path.Text) + "\Master_Mapping.csv").ToList()
                'Add the entries from the mapping file which are present in the name_list to the BrewPID_SymbolMappingForm Component_DataGrid 
                For Each row_present In mapping_file
                    components_in_MasterMapping.Add(row_present.Split(",")(0), row_present.Split(",")(1) + "," + row_present.Split(",")(2))
                    If name_list.contains(row_present.Split(",")(0)) Then
                        BrewPID_SymbolMappingForm.Column1.Items.Add(row_present.Split(",")(0))
                        Dim row As ArrayList = New ArrayList
                        row.Add(row_present.Split(",")(0))
                        row.Add(row_present.Split(",")(1))
                        row.Add("...")
                        row.Add(row_present.Split(",")(2))
                        BrewPID_SymbolMappingForm.Component_DataGrid.Rows.Add(row.ToArray())
                        'Removing the element of name_list one by one after putting them in datagrid
                        name_list.Remove(row_present.Split(",")(0))
                    End If
                Next
            End If
            'Add all the entries from the name_list (new unique entries only remain) to the BrewPID_SymbolMappingForm Component_Datagrid
            For Each component In name_list
                BrewPID_SymbolMappingForm.Column1.Items.Add(component)
                Dim row As ArrayList = New ArrayList
                row.Add(component)
                row.Add("")
                row.Add("...")
                BrewPID_SymbolMappingForm.Component_DataGrid.Rows.Add(row.ToArray())
            Next
        Catch ex As Exception
            WriteLog("Error in 'add_to_datagrid' subprocess : " + ex.Message)
            PropStreamWriterObject.Close()
            Close()
        End Try
    End Sub

    ''' <summary>
    ''' 'check_for_master_mapping' subprocess checks if the Master Mapping file exists, if not, create an blank Master Mapping file
    ''' </summary>
    ''' <param name="File_Path"></param>
    Public Sub check_for_file(File_Path, File_Name)
        Try
            If Not File.Exists(Path.GetDirectoryName(File_Path.Text) + File_Name) Then
                File.WriteAllText(Path.GetDirectoryName(File_Path.Text) + File_Name, "")
            End If
        Catch ex As Exception
            WriteLog("Error in 'check_for_master_mapping' subprocess : " + ex.Message)
            PropStreamWriterObject.Close()
            Close()
        End Try

    End Sub

    ''' <summary>
    ''' 'get_index_for_name' function gets the index of the column in which the Symbol names are stored
    ''' </summary>
    ''' <param name="type_lines"></param>
    ''' <param name="name_index"></param>
    ''' <param name="File_Name"></param>
    ''' <returns>name_index, Integerr</returns>
    Public Function get_index_for_name(type_lines, name_index, File_Name) As Integer
        Dim array_headers As String()
        Try
            'Split the header row of the Symbol CSV
            array_headers = type_lines(0).Split(",")
            'Check which index of "data" has the same value as that of the name column of the file entered by the user in BrewPID_MainForm
            name_index = array_headers.ToList().IndexOf(File_Name.SelectedItem)
        Catch ex As Exception
            WriteLog("Error in 'get_index_for_name' function : " + ex.Message)
            PropStreamWriterObject.Close()
            Close()
        End Try
        Return name_index
    End Function

    ''' <summary>
    ''' 'get_list_of_components' function gets the list of all unique Symbols present in the Symbols CSV
    ''' </summary>
    ''' <param name="type_lines"></param>
    ''' <param name="name_index"></param>
    ''' <returns>name_list, List(Of String)(</returns>
    Public Function get_list_of_components(type_lines, name_index) As List(Of String)
        Dim name_list As New List(Of String)
        Try
            Dim single_row_name
            'Iterate through each entry in type_lines and add the Symbol name to name_list if it is not already present in the name_list
            For Each single_row In type_lines
                single_row_name = single_row.Split(",")(name_index)
                If name_list.Count = 0 Then
                    name_list.Add(single_row_name)
                ElseIf Not name_list.Contains(single_row_name) Then
                    name_list.Add(single_row_name)
                End If
            Next
        Catch ex As Exception
            WriteLog("Error in 'get_list_of_components' function : " + ex.Message)
            PropStreamWriterObject.Close()
            Close()
        End Try
        Return name_list
    End Function

    Public Shared LogFilePath As String

    ''' <summary>
    ''' 'WriteLog' subprocess to write into the log file : Written by Pankaj
    ''' </summary>
    ''' <param name="pstrMessage"></param>
    Public Sub WriteLog(pstrMessage As String)
        Try
            PropStreamWriterObject.WriteLine(pstrMessage)
        Catch ex As Exception
            Throw
            Close()
        End Try
    End Sub

    ''' <summary>
    ''' 'CloseLog' subprocess closes the log file : Written by Pankaj
    ''' </summary>
    Public Sub CloseLog()
        Try
            PropStreamWriterObject.Close()
        Catch ex As Exception
            Throw
            Close()
        End Try
    End Sub

    ''' <summary>
    ''' 'Component_Button_Browse_Click' subprocess defines what happens after Component_Button_Browse button is clicked in BrewPID_MainForm
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Public Sub Component_Button_Browse_Click(sender As Object, e As EventArgs) Handles Component_Button_Browse.Click
        Try
            BrewPID_SymbolAttributesForm.component_submit_button_used = False
            'Checks for the user to select a CSV file (preferably of Symbols) from the OpenFileDialog1
            If OpenFileDialog_1.ShowDialog = DialogResult.OK Then
                component_columns = New List(Of String)
                'Clear all the filled entires of all the fields
                BrewPID_SymbolMappingForm.Component_DataGrid.Rows.Clear()
                'Call the 'ClearEntities' and 'AddComboboxItems' subprocess
                ClearEntities()
                AddComboboxItems()
            End If
        Catch ex As Exception
            WriteLog("Error in 'Component_Button_Browse_Click' subprocess" + ex.Message)
            PropStreamWriterObject.Close()
            Close()
        End Try
    End Sub

    ''' <summary>
    ''' 'Pipeline_Button_Browse_Click' subprocess defines what happens after Pipeline_Button_Browse button is clicked in BrewPID_MainForm
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Public Sub Pipeline_Button_Browse_Click(sender As Object, e As EventArgs) Handles Pipeline_Button_Browse.Click
        Try
            BrewPID_SymbolAttributesForm.pipeline_submit_button_used = False
            'Checks for the user to select a CSV file (preferably of Pipelines) from the OpenFileDialog1
            If OpenFileDialog_1.ShowDialog = DialogResult.OK Then
                pipeline_columns = New List(Of String)
                'Clear all the filled entires of all the fields
                BrewPID_SymbolMappingForm.Component_DataGrid.Rows.Clear()
                'Call the 'ClearEntities' and 'AddComboboxItems' subprocess
                ClearEntities()
                AddComboboxItems()
            End If
        Catch ex As Exception
            WriteLog("Error in 'Pipeline_button_browse_Click' subprocess" + ex.Message)
            PropStreamWriterObject.Close()
            Close()
        End Try

    End Sub

    ''' <summary>
    ''' 'BrewPID_Button_Submit_Click' subprocess defines what happens after BrewPID_Button_Submit button is clicked in BrewPID_MainForm
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub BrewPID_Button_Submit_Click(sender As Object, e As EventArgs) Handles BrewPID_Button_Submit.Click
        Try
            'Hide the form and begin the backend processing 
            Hide()
            MessageBox.Show("The placing of symols and lines has begun")
            'Call the Begin_Process subprocess form the Place_Symbols_And_Lines module in PlaceSymbols.vb file
            Begin_Process()
            MessageBox.Show("The placing of symbols and lines has finished")
            'Close the form after the backend processing is finished
            Close()
        Catch ex As Exception
            WriteLog("Error in 'BrewPID_Button_Submit_Click' subprocess" + ex.Message)
            PropStreamWriterObject.Close()
            Close()
        End Try
    End Sub

    ''' <summary>
    ''' 'Component_Button_Access_Mapping_Click' subprocess defines what happens after Component_Button_Access_Mapping button is clicked in BrewPID_MainForm
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Component_Button_Access_Mapping_Click(sender As Object, e As EventArgs) Handles Component_Button_Access_Mapping.Click
        Try
            'Check if a valid Component CSV is provided along with a proper column nmae of this CSV before acivating the Component_Button_Access_Mapping button
            If ((File.Exists(Component_Text_Path.Text)) And (Not String.IsNullOrWhiteSpace(Component_Text_Name.Text))) Then
                'Call the check_for_file function
                check_for_file(Component_Text_Path, "\Master_Mapping.csv")
                Dim name_list As List(Of String) = GetNameList(Component_Text_Name)
                'Call add_to_datagrid function
                add_to_datagrid(name_list, Component_Text_Path)
                'Show BrewPID_SymbolMappingForm
                BrewPID_SymbolMappingForm.ShowDialog()
            End If
        Catch ex As Exception
            WriteLog("Error in 'Component_Button_Access_Mapping_Click' subprocess" + ex.Message)
            PropStreamWriterObject.Close()
            Close()
        End Try
    End Sub

    ''' <summary>
    ''' 'BrewPID_Button_Cancel_Click' subprocess defines what happens after BrewPID_Button_Cancel button is clicked in BrewPID_MainForm
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub BrewPID_Button_Cancel_Click(sender As Object, e As EventArgs) Handles BrewPID_Button_Cancel.Click
        Try
            'Close the log file and trminate the program by closing BrewPID_MainForm
            PropStreamWriterObject.Close()
            Close()
        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' 'Pipeline_Button_Access_Mapping_Click' subprocess defines what happens after BrewPID_Button_Cancel button is clicked in BrewPID_MainForm
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Pipeline_Button_Access_Mapping_Click(sender As Object, e As EventArgs) Handles Pipeline_Button_Access_Mapping.Click
        Try
            'Check if a valid Pipeline CSV is provided along with a proper column nmae of this CSV before acivating the Pipeline_Button_Access_Mapping button
            If ((File.Exists(Pipeline_Text_Path.Text)) And (Not String.IsNullOrWhiteSpace(Pipeline_Text_Name.Text))) Then
                'Call the check_for_master_mapping function
                check_for_file(Pipeline_Text_Path, "\Master_Mapping.csv")
                Dim name_list As List(Of String) = GetNameList(Pipeline_Text_Name)
                'Call add_to_datagrid function
                add_to_datagrid(name_list, Pipeline_Text_Path)
                'Show BrewPID_SymbolMappingForm
                BrewPID_SymbolMappingForm.ShowDialog()
            End If
        Catch ex As Exception
            WriteLog("Error in 'Pipeline_Button_Access_Mapping_Click' subprocess" + ex.Message)
            PropStreamWriterObject.Close()
            Close()
        End Try
    End Sub

    ''' <summary>
    ''' 'BrewPID_MainForm_Load' subprocess defines what happens when the BrewPID_MainForm loads
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Public Sub BrewPID_MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim objStreamWriter As StreamWriter
        Try
            'Declare datagrid_component_attributes and datagrid_pipeline_attributes as empty dictionaries so that if the 'Add Attribute Button' is not clicked, no error occurs
            BrewPID_SymbolAttributesForm.datagrid_component_attributes = New Dictionary(Of String, String)
            BrewPID_SymbolAttributesForm.datagrid_pipeline_attributes = New Dictionary(Of String, String)
            'Create the log file and activate it for writing : Written by Pankaj
            Dim CurrentDir = Environment.CurrentDirectory
            LogFilePath = CurrentDir + "\BrewPIDLog" + "-" + DateTime.Today.ToString("yyyyMMdd") + "." + "log"
            ' Check for the file existence if not then create new one
            If (File.Exists(LogFilePath)) Then
                'Delete the file. Everytime it will create new file
                File.Delete(LogFilePath)
            End If
            Dim FileStream = New FileStream(LogFilePath, FileMode.CreateNew)
            objStreamWriter = New StreamWriter(FileStream)
            PropStreamWriterObject = objStreamWriter
            SPPID_Text_Unit.SelectedIndex = 1
        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' 'IsFileOpen' subprocess checks if the file is open, prompts the user to close it in case it is open
    ''' </summary>
    ''' <param name="file"></param>
    Private Sub IsFileOpen(ByVal file As FileInfo)
        Dim stream As FileStream = Nothing
        Try
            stream = file.Open(FileMode.Open, FileAccess.ReadWrite, FileShare.None)
            stream.Close()
        Catch ex As Exception
            If TypeOf ex Is IOException AndAlso IsFileLocked(ex) Then
                MessageBox.Show("The file " + OpenFileDialog_1.FileName + " is open. Please close the file before proceeding further.")
            End If
        End Try
    End Sub

    ''' <summary>
    ''' 'IsFileLocked' function checks if the file is locked
    ''' </summary>
    ''' <param name="exception"></param>
    ''' <returns></returns>
    Private Shared Function IsFileLocked(exception As Exception) As Boolean
        Dim errorCode As Integer
        Try
            errorCode = Marshal.GetHRForException(exception) And ((1 << 16) - 1)
        Catch ex As Exception
            PropStreamWriterObject.Close()
            BrewPID_MainForm.Close()
        End Try
        Return errorCode = 32 OrElse errorCode = 33
    End Function

    ''' <summary>
    ''' 'Component_Button_Add_Attribute_Click' subprocess Defines what happens when the Component_Button_Add_Attribute button is clicked in BrewPID_MainForm
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Public Sub Component_Button_Add_Attribute_Click(sender As Object, e As EventArgs) Handles Component_Button_Add_Attribute.Click
        Try
            If ((File.Exists(Component_Text_Path.Text)) And (Not BrewPID_SymbolAttributesForm.component_submit_button_used)) Then
                'Call 'EnterComboboxEntries' and 'check_for_file' subprocesses
                EnterComboboxEntries()
                check_for_file(Component_Text_Path, "\Symbol_Attribute_Mapping.csv")
                'Check if the Symbol_Attribute_Mapping.csv is empty or not
                If File.ReadAllText(Path.GetDirectoryName(Component_Text_Path.Text) + "\Symbol_Attribute_Mapping.csv").Length <> 0 Then
                    'Call 'AddRowsInAttributeDataGrid' subprocess
                    AddRowsInAttributeDataGrid(Component_Text_Path.Text)
                End If
                'Show BrewPID_SymbolAttributesFrom
                BrewPID_SymbolAttributesForm.ShowDialog()
            ElseIf ((File.Exists(Component_Text_Path.Text)) And (BrewPID_SymbolAttributesForm.Component_submit_button_used)) Then
                'Call 'EnterComboboxEntries' and 'check_for_file' subprocess
                EnterComboboxEntries()
                'Display the entries present in the datagrid_component_attributes of BrewPID_SymbolAttributesForm in the BrewPID_SymbolAttributesForm
                For Each pair In BrewPID_SymbolAttributesForm.datagrid_component_attributes
                    Dim row As ArrayList = New ArrayList
                    row.Add(pair.Key)
                    row.Add(pair.Value)
                    BrewPID_SymbolAttributesForm.Symbol_Attribute_Datagrid.Rows.Add(row.ToArray())
                Next
                'Show BrewPID_SymbolAttributesFrom
                BrewPID_SymbolAttributesForm.ShowDialog()
            End If
        Catch ex As Exception
            WriteLog("Error in 'Component_Button_Add_Attribute_Click' subprocess" + ex.Message)
            PropStreamWriterObject.Close()
            Close()
        End Try
    End Sub

    ''' <summary>
    ''' 'Pipeline_Button_Add_Attribute_Click' subprocess defines what happens when the Pipeline_Button_Add_Attribute button is clicked in BrewPID_MainForm
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Pipeline_Button_Add_Attribute_Click(sender As Object, e As EventArgs) Handles Pipeline_Button_Add_Attribute.Click
        Try
            If ((File.Exists(Pipeline_Text_Path.Text)) And (Not BrewPID_SymbolAttributesForm.pipeline_submit_button_used)) Then
                'Call 'EnterComboboxEntries' and 'check_for_file' subprocess
                EnterComboboxEntries()
                check_for_file(Pipeline_Text_Path, "\Symbol_Attribute_Mapping.csv")
                'Check if the Pipeline_Attribute_Mapping.csv is empty or not
                If File.ReadAllText(Path.GetDirectoryName(Pipeline_Text_Path.Text) + "\Symbol_Attribute_Mapping.csv").Length <> 0 Then
                    'Call 'AddRowsInAttributeDataGrid' subprocess
                    AddRowsInAttributeDataGrid(Pipeline_Text_Path.Text)
                End If
                'Show BrewPID_PipelineAttributesFrom
                BrewPID_SymbolAttributesForm.ShowDialog()
            ElseIf ((File.Exists(Pipeline_Text_Path.Text)) And (BrewPID_SymbolAttributesForm.pipeline_submit_button_used)) Then
                'Call 'EnterComboboxEntries' and 'check_for_file' subprocess
                EnterComboboxEntries()
                'Display the entries present in the datagrid_pipeline_attributes of BrewPID_SymbolAttributesForm in the BrewPID_SymbolAttributesForm
                For Each pair In BrewPID_SymbolAttributesForm.datagrid_pipeline_attributes
                    Dim row As ArrayList = New ArrayList
                    row.Add(pair.Key)
                    row.Add(pair.Value)
                    BrewPID_SymbolAttributesForm.Symbol_Attribute_Datagrid.Rows.Add(row.ToArray())
                Next
                'Show BrewPID_PipelineAttributesFrom
                BrewPID_SymbolAttributesForm.ShowDialog()
            End If
        Catch ex As Exception
            WriteLog("Error in 'Pipeline_Button_Add_Attribute_Click' subprocess" + ex.Message)
            PropStreamWriterObject.Close()
            Close()
        End Try
    End Sub

    ''' <summary>
    ''' 'ClearEntities' subprocess clears the entries in the fields of the form corresponding to the tab which is currently active in TabControl_BrewPID
    ''' </summary>
    Private Sub ClearEntities()
        'Check whether the entries wish to be cleared are in the Componenet File or Pipeline file
        If TabControl_BrewPID.SelectedIndex = 0 Then
            'Clear all the filled entires of all the fields
            Component_Text_Name.Items.Clear()
            Component_Text_X.Items.Clear()
            Component_Text_Y.Items.Clear()
            Component_Text_Rotation.Items.Clear()
            Component_Text_Path.Text = OpenFileDialog_1.FileName
        ElseIf TabControl_BrewPID.SelectedIndex = 1 Then
            'Clear all the filled entires of all the fields
            Pipeline_Text_Name.Items.Clear()
            Pipeline_Text_StartX.Items.Clear()
            Pipeline_Text_StartY.Items.Clear()
            Pipeline_Text_EndX.Items.Clear()
            Pipeline_Text_EndY.Items.Clear()
            Pipeline_Text_Path.Text = OpenFileDialog_1.FileName
        End If
    End Sub

    ''' <summary>
    ''' 'AddComboboxItems' subprocess adds headers of the Symbol/Pipeline CSV to the comboboc items corresponding to the tab which is currently active in TabControl_BrewPID
    ''' </summary>
    Private Sub AddComboboxItems()
        Dim file_lines As List(Of String)
        'Open the Symbol/Pipeline CSV
        Dim file_fileinfo = New FileInfo(OpenFileDialog_1.FileName)
        'Call IsfileOpen subprocess
        IsFileOpen(file_fileinfo)
        'Read all lines of the Symols/Pipeline CSV and add the column headers to all dropdown lists present
        file_lines = File.ReadAllLines(OpenFileDialog_1.FileName).ToList()
        Dim data As String()
        data = file_lines(0).Split(",")
        Dim header_index_component As Integer
        If TabControl_BrewPID.SelectedIndex = 0 Then
            For header_index_component = 0 To (data.Length() - 1)
                Component_Text_Name.Items.Add(data(header_index_component))
                Component_Text_X.Items.Add(data(header_index_component))
                Component_Text_Y.Items.Add(data(header_index_component))
                Component_Text_Rotation.Items.Add(data(header_index_component))
                component_columns.Add(data(header_index_component))
            Next
        ElseIf TabControl_BrewPID.SelectedIndex = 1 Then
            For header_index_pipingline = 0 To (data.Length() - 1)
                Pipeline_Text_StartX.Items.Add(data(header_index_pipingline))
                Pipeline_Text_StartY.Items.Add(data(header_index_pipingline))
                Pipeline_Text_EndX.Items.Add(data(header_index_pipingline))
                Pipeline_Text_EndY.Items.Add(data(header_index_pipingline))
                Pipeline_Text_Name.Items.Add(data(header_index_pipingline))
                pipeline_columns.Add(data(header_index_pipingline))
            Next
        End If
    End Sub

    ''' <summary>
    ''' 'GetNameList' function procures and returns the name_list from the Pipieline/Symbols CSV
    ''' </summary>
    ''' <param name="filename"></param>
    ''' <returns>name_list, a List</returns>
    Private Function GetNameList(filename)
        Dim file_lines As List(Of String)
        Dim name_list As New List(Of String)
        Dim name_index As Integer = -1
        'Read the Symbols CSV
        file_lines = File.ReadAllLines(OpenFileDialog_1.FileName).ToList()
        'Get name_index by calling index_for_name function
        name_index = get_index_for_name(file_lines, name_index, filename)
        'Remove the header row (first row) for the Symbol CSV
        file_lines.RemoveRange(0, 1)
        'Get name_list by calling get_list_of_components function
        name_list = get_list_of_components(file_lines, name_index)
        Return name_list
    End Function

    ''' <summary>
    ''' 'EnterComboboxEntries' subprocess adds the entries from the column_headers list to the combobox column items of BrewPID_SymbolAttributesForm
    ''' </summary>
    Private Sub EnterComboboxEntries()
        'Clear the rows of Symbol_Attribute_Datagrid as well as the items of the ComboboxColumn of Symbol_Attribute_Datagrid
        BrewPID_SymbolAttributesForm.Symbol_Attribute_Datagrid.Rows.Clear()
        BrewPID_SymbolAttributesForm.Column2.Items.Clear()
        'Add all Column Headers in the Column2 items of BrewPID_SymbolAttributesForm
        If TabControl_BrewPID.SelectedIndex = 0 Then
            For Each column_header In component_columns
                BrewPID_SymbolAttributesForm.Column2.Items.Add(column_header)
            Next
        Else
            For Each column_header In pipeline_columns
                BrewPID_SymbolAttributesForm.Column2.Items.Add(column_header)
            Next
        End If

    End Sub

    ''' <summary>
    ''' 'AddRowsInAttributeDataGrid' subprocess adds the attributes common to the Symbol_Attribute_Mapping.csv as well as in the headers of the the Pipeline/Symbol CSV to the Symbol_Attribute_Datagrid of BrewPID_SymbolAttributesForm
    ''' </summary>
    ''' <param name="file_name"></param>
    Private Sub AddRowsInAttributeDataGrid(file_name)
        'Convert the headers of the Symbols CSV to Symbol_CSV_Headers_List
        Dim Symbol_CSV_Headers_List As List(Of String) = File.ReadAllLines(file_name).ToList()(0).Split(",").ToList()
        'Convert the Symbols_Attribute_Maping.csv to attribute_list
        Dim attribute_list As List(Of String) = File.ReadAllLines(Path.GetDirectoryName(file_name) + "\Symbol_Attribute_Mapping.csv").ToList()
        'Iterate through every entry of the attribute_list and add the entry to the Symbol_Attribute_Datagrid of the BrewPID_SymbolAttributesForm in case the attribute is present in the Symbol_CSV_Headers_List
        For Each single_row In attribute_list
            If Symbol_CSV_Headers_List.Contains(single_row.Split(",")(1)) Then
                Dim row As ArrayList = New ArrayList
                row.Add(single_row.Split(",")(0))
                row.Add(single_row.Split(",")(1))
                BrewPID_SymbolAttributesForm.Symbol_Attribute_Datagrid.Rows.Add(row.ToArray())
            End If
        Next
    End Sub
End Class


