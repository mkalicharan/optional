﻿Imports Llama
Imports Microsoft.VisualBasic.FileIO
Imports Plaice
Imports System.IO

''' <summary>
'''Class 'sortuils' : Created by Kartik (no commenting) 
''' </summary>
Public Class sortutils
    Implements System.Collections.IComparer
    Dim mode As Boolean = False
    Public Sub New(ByRef sorttype As String)
        If (sorttype = "x") Then
            mode = True
        End If
    End Sub
    Public Function Compare(x As Object, y As Object) As Integer Implements IComparer.Compare

        If mode = False Then
            If x(0).CompareTo(y(0)) = 0 Then
                If x(1).CompareTo(y(1)) = 0 Then
                    Return x(3).CompareTo(y(3))
                Else
                    Return x(1).CompareTo(y(1))
                End If
            Else
                Return x(0).CompareTo(y(0))
            End If
        Else
            If x(1).CompareTo(y(1)) = 0 Then
                If x(0).CompareTo(y(0)) = 0 Then
                    Return x(2).CompareTo(y(2))
                Else
                    Return x(0).CompareTo(y(0))
                End If
            Else
                Return x(1).CompareTo(y(1))
            End If
        End If
    End Function
End Class

''' <summary>
''' Class 'ComponentColumnDetails' to store the name of the Symbol CSV and the required column details from this CSV
''' </summary>
Public Class ComponentColumnDetails

    Public Shared CSVPath As String
    Public Shared SymbolName As String
    Public Shared XColumnName As String
    Public Shared YColumnName As String
    Public Shared CellNameColumnName As String
    Public Shared RotationColumnName As String
    Public Shared AttributeColumnName As String
    Public Shared Unit As String

End Class

''' <summary>
''' Class 'LineColumnDetails' to store the name of the PipingLine CSV and the required column details from this CSV
''' </summary>
Public Class LineColumnDetails

    Public Shared CSVPath As String
    Public Shared PipelineName As String
    Public Shared X1ColumnName As String
    Public Shared X2ColumnName As String
    Public Shared Y1ColumnName As String
    Public Shared Y2ColumnName As String
    Public Shared AttributeColumnName As String
    Public Shared Unit As String

End Class

''' <summary>
''' Class 'SPPIDGridDetails' to store the grid details for SPPID
''' </summary>
Public Class SPPIDGridDetails

    Public Shared GridDensity As Double
    Public Shared GridDensityUnit As String
    Public Shared GridIndex As Integer

End Class

''' <summary>
''' Class 'Symbol' to store the values of various attributes of a symbol
''' </summary>
Public Class Symbol

    Public Shared X As String
    Public Shared Y As String
    Public Shared Location As String
    Public Shared Type As String
    Public Shared Rotation As String
    Public Shared Tag As String
    Public Shared InstrumenTypeModifier As String
    Public Shared TagSequenceNo As String
    Public Shared TagSuffix As String
    Public Shared AttributeDictionary As Dictionary(Of String, String)

End Class

''' <summary>
''' Class 'SymbolLists' to store the details of various symbol types into separate lists
''' </summary>
Public Class SymbolLists

    Public Shared MainEquipment As List(Of List(Of Object)) = New List(Of List(Of Object))
    Public Shared SubEquipment As List(Of List(Of Object)) = New List(Of List(Of Object))
    Public Shared PipingComp As List(Of List(Of Object)) = New List(Of List(Of Object))
    Public Shared Instrument As List(Of List(Of Object)) = New List(Of List(Of Object))
    Public Shared Label As List(Of List(Of Object)) = New List(Of List(Of Object))
    Public Shared Design As List(Of List(Of Object)) = New List(Of List(Of Object))
    Public Shared MainEquipmentSymbol As List(Of LMSymbol) = New List(Of LMSymbol)

End Class

''' <summary>
''' Class 'PipingLine' to store the values of various attributes of a line
''' </summary>
Public Class PipingLine

    Public Shared X1 As String
    Public Shared Y1 As String
    Public Shared X2 As String
    Public Shared Y2 As String
    Public Shared Location As String
    Public Shared Type As String
    Public Shared AttributeDictionary As Dictionary(Of String, String)

End Class

''' <summary>
''' Class 'AttributeDictionaries' to store the attributes of the symbols (barring X, Y, roatation, and path)
''' </summary>
Public Class AttributeDictionaries
    Public Shared SymbolDictonary As New Dictionary(Of String, Integer)
    Public Shared MainEquipmentDictonary As New Dictionary(Of String, Integer)
    Public Shared SubEquipmentDictonary As New Dictionary(Of String, Integer)
    Public Shared PipingCompDictonary As New Dictionary(Of String, Integer)
    Public Shared InstrumentDictonary As New Dictionary(Of String, Integer)
    Public Shared PipelineDictonary As New Dictionary(Of String, Integer)
End Class

''' <summary>
''' Class 'MasterMappingFile' to store the Master Mapping file as a global Dictionary
''' </summary>
Public Class MasterMappingFile
    Public Shared MasterMappingDictionary As New Dictionary(Of String, String)
End Class

''' <summary>
''' Class 'ObjectPlacement' to create a global Placement object
''' </summary>
Public Class ObjectPlacment
    Public Shared objplacement As Placement = New Placement
End Class

''' <summary>
''' Module 'Place_Symbols_and_Lines' to place symbols and lines
''' </summary>
Module Place_Symbols_and_Lines
    Dim objStreamWriter As StreamWriter
    ''' <summary>
    ''' Property 'PropStreamWriterObject' : By Pankaj
    ''' </summary>
    ''' <returns></returns>
    Property PropStreamWriterObject As StreamWriter
        Get
            Return objStreamWriter
        End Get
        Set(ByVal Value As StreamWriter)
            objStreamWriter = Value
        End Set
    End Property

    ''' <summary>
    ''' Subprocess 'Begin_Process' which calls various other subprocess for handling the placing of lines and symbols
    ''' </summary>
    Sub Begin_Process()
        Try
            'Call 'GenerateMasterMappingList' subprocess 
            GenerateMasterMappingList()
            'Call 'CollectParametersFromForm' subprocess
            CollectParametersFromForm()
            'Call 'CheckForFile' function and declare that the PipelineFile does not exist if the function returns True
            If CheckForFile(LineColumnDetails.CSVPath) Then
                WriteLog("Pipeline File doesn't exist:- " + LineColumnDetails.CSVPath)
            Else
                getPipingData()
            End If
            'Call 'CheckForFile' function and declare that the CompoentFile does not exist if the function returns True
            If CheckForFile(ComponentColumnDetails.CSVPath) Then
                WriteLog("Component File doesn't exist:- " + ComponentColumnDetails.CSVPath)
            Else
                'Call 'GetComponentData' subprocess
                GetComponentData()
                'Call 'PlaceInstruments' subprocess
                PlaceInstruments()
                'Call 'PlacePipingComp' subprocess
                PlacePipingComp()
            End If
            'Call 'ReleaseCOMObjects' function
            ReleaseCOMObjects(ObjectPlacment.objplacement)
            'Call 'CloseLog'  subprocess
            CloseLog()
        Catch ex As Exception
            WriteLog("Error in 'Begin_Process subprocess' - " + ex.Message)
            CloseLog()
            MessageBox.Show("An error has occurred. Please refer to the log file for further information.")
            BrewPID_MainForm.Close()
        End Try
    End Sub

    ''' <summary>
    ''' Subprocess 'GenerateMasterMappingList' which converts the master mapping CSV to a list and calls the "GenerateMasterMappingDictionary' to add the entries to MaterMappingDictionary
    ''' </summary>
    Private Sub GenerateMasterMappingList()
        Try
            'Check if the user has provided the path to the Component CSV
            If BrewPID_MainForm.Component_Text_Path.Text <> "" Then
                'Convert the Master_Mapping.csv to List
                Dim mastermappinglist As List(Of String) = File.ReadAllLines(Path.GetDirectoryName(BrewPID_MainForm.Component_Text_Path.Text) + "\Master_Mapping.csv").ToList()
                'Call the GenerateMasterMappingDictionary subprocess
                GenerateMasterMappingDictionary(mastermappinglist)
                'Check if the user has provided the path to the Pipeline CSV
            ElseIf BrewPID_MainForm.Pipeline_Text_Path.Text <> "" Then
                'Convert the Master_Mapping.csv to List
                Dim mastermappinglist As List(Of String) = File.ReadAllLines(Path.GetDirectoryName(BrewPID_MainForm.Pipeline_Text_Path.Text) + "\Master_Mapping.csv").ToList()
                'Call the GenerateMasterMappingDictionary subprocess
                GenerateMasterMappingDictionary(mastermappinglist)
            End If
        Catch ex As Exception
            WriteLog("Error in 'GenerateMasterMappingList' subprocess - " + ex.Message)
            MessageBox.Show("An error has occurred. Please refer to the log file for further information.")
            CloseLog()
            BrewPID_MainForm.Close()
            'Throw
        End Try
    End Sub

    ''' <summary>
    ''' 'GenerateMasterMappingDictionary' subprocess iterates through elements of the mastermappinglist and add them to the MasterMappingDictionary in proper format
    ''' </summary>
    ''' <param name="mastermappinglist"></param>
    Private Sub GenerateMasterMappingDictionary(mastermappinglist)
        Try
            'Iterate through each entry in the mastermappinglist 
            For Each single_row In mastermappinglist
                'Store the Symbol name as Key and its Path,Type as Value in the MasterMappingDictionary
                Dim key As String = single_row.Split(",")(0)
                Dim value As String = single_row.Split(",")(1) + "," + single_row.Split(",")(2)
                MasterMappingFile.MasterMappingDictionary.Add(key, value)
            Next
        Catch ex As Exception
            WriteLog("Error in 'GenerateMasterMappingDictionary' subprocess - " + ex.Message)
            CloseLog()
            MessageBox.Show("An error has occurred. Please refer to the log file for further information.")
            BrewPID_MainForm.Close()
            'Throw
        End Try
    End Sub

    ''' <summary>
    ''' Subprocess 'CollectParametersFromForm' to collect the various parameters of PipingLine, Symbols and SPPID Grid from BrewPID_MainForm
    ''' </summary>
    Private Sub CollectParametersFromForm()
        Try
            WriteLog("Collecting ComponentFile details from Windows Form")
            'Collecting required parameters of Symbols
            ComponentColumnDetails.CSVPath = BrewPID_MainForm.Component_Text_Path.Text
            ComponentColumnDetails.SymbolName = BrewPID_MainForm.Component_Text_Name.Text
            ComponentColumnDetails.XColumnName = BrewPID_MainForm.Component_Text_X.Text
            ComponentColumnDetails.YColumnName = BrewPID_MainForm.Component_Text_Y.Text
            ComponentColumnDetails.RotationColumnName = BrewPID_MainForm.Component_Text_Rotation.Text
            ComponentColumnDetails.Unit = BrewPID_MainForm.Component_Text_Unit.Text

            WriteLog("Collecting PipeLineFile details from config file")
            'Collecting required parameters of Pipelines
            LineColumnDetails.CSVPath = BrewPID_MainForm.Pipeline_Text_Path.Text
            LineColumnDetails.PipelineName = BrewPID_MainForm.Pipeline_Text_Name.Text
            LineColumnDetails.X1ColumnName = BrewPID_MainForm.Pipeline_Text_StartX.Text
            LineColumnDetails.Y1ColumnName = BrewPID_MainForm.Pipeline_Text_StartY.Text
            LineColumnDetails.X2ColumnName = BrewPID_MainForm.Pipeline_Text_EndX.Text
            LineColumnDetails.Y2ColumnName = BrewPID_MainForm.Pipeline_Text_EndY.Text
            LineColumnDetails.Unit = BrewPID_MainForm.Pipeline_Text_Unit.Text

            WriteLog("Collecting SPPID details from config file")
            'Collecting required SPPID Grid Details
            Double.TryParse(BrewPID_MainForm.SPPID_Text_Density.Text, SPPIDGridDetails.GridDensity)
            SPPIDGridDetails.GridDensityUnit = BrewPID_MainForm.SPPID_Text_Unit.Text
            SPPIDGridDetails.GridIndex = CInt(BrewPID_MainForm.SPPID_Text_Index.Text)

            'Call Function ConfigParameterValidation and declare that parameters are insufficient if it returns True
            If ConfigParameterValidation() Then
                Throw New Exception("Required parameters are Not mentioned in the config file")
            End If

        Catch ex As Exception
            WriteLog("Error in the 'CollectParametersFromForm' subprocess - " + ex.Message)
            MessageBox.Show("An error has occurred. Please refer to the log file for further information.")
            CloseLog()
            BrewPID_MainForm.Close()
            'Throw
        End Try

    End Sub

    ''' <summary>
    ''' 'ConfigParameterValidation' function checks if all the required parameters are provided by the user in BrewPID_MainForm : Written by Pankaj
    ''' </summary>
    ''' <returns>blnParameterValidationFlag, Boolean</returns>
    Private Function ConfigParameterValidation() As Boolean
        Dim blnParameterValidationFlag As Boolean = False
        Try
            If (((Not String.IsNullOrWhiteSpace(ComponentColumnDetails.CSVPath)) And (String.IsNullOrWhiteSpace(ComponentColumnDetails.XColumnName) Or String.IsNullOrWhiteSpace(ComponentColumnDetails.YColumnName) Or String.IsNullOrWhiteSpace(ComponentColumnDetails.RotationColumnName) Or String.IsNullOrWhiteSpace(ComponentColumnDetails.Unit))) Or ((Not String.IsNullOrWhiteSpace(LineColumnDetails.CSVPath)) And (String.IsNullOrWhiteSpace(LineColumnDetails.X1ColumnName) Or String.IsNullOrWhiteSpace(LineColumnDetails.Y1ColumnName) Or String.IsNullOrWhiteSpace(LineColumnDetails.X2ColumnName) Or String.IsNullOrWhiteSpace(LineColumnDetails.X1ColumnName) Or String.IsNullOrWhiteSpace(LineColumnDetails.Unit))) Or String.IsNullOrWhiteSpace(CStr(SPPIDGridDetails.GridDensity)) Or String.IsNullOrWhiteSpace(SPPIDGridDetails.GridDensityUnit) Or String.IsNullOrWhiteSpace(CStr(SPPIDGridDetails.GridIndex))) Then
                blnParameterValidationFlag = True
            End If
            If (blnParameterValidationFlag = True) Then
                WriteLog("Required SPPID parameters are Not mentioned in config file")
            End If
        Catch ex As Exception
            WriteLog("Error in 'ConfigParameterValidation' function  - " + ex.Message)
            'Throw
        End Try
        Return blnParameterValidationFlag
    End Function

    ''' <summary>
    ''' 'CheckForFile' function checks if the file exists and returns True if it does not exist.
    ''' </summary>
    ''' <param name="Filename"></param>
    ''' <returns>blnValidationFlag, Boolean</returns>
    Private Function CheckForFile(Filename) As Boolean
        Dim blnValidationFlag As Boolean = False
        Try
            If Not (File.Exists(Filename)) Then
                blnValidationFlag = True
            End If
        Catch ex As Exception
            WriteLog("Error in 'CheckForFile' function for " + Filename + " :- " + ex.Message)
            'Throw
        End Try
        Return blnValidationFlag
    End Function

    ''' <summary>
    ''' 'GetComponentData' subprocess deals with getting the component data based on the Column names from BrewPID_MainForm and segregating the data based on symbol type
    ''' </summary>
    Private Sub GetComponentData()
        Try
            Dim blnFirstRow As Boolean = True
            Dim XIndex As Integer
            Dim YIndex As Integer
            Dim SymbolNameIndex As Integer
            Dim RotationIndex As Integer
            Dim Scale As Double
            Dim dict_key As String
            Dim dict_value As Integer
            Dim Symbol_Parameters As New List(Of Object)
            'Scale appropriately to metres based on the unit provided in the Form1
            If (ComponentColumnDetails.Unit = "inches") Then
                Scale = 0.0254
            Else
                Scale = 0.001
            End If

            WriteLog("Processing component file : " + ComponentColumnDetails.CSVPath)
            'Parse the CSV
            Dim CSVPath = ComponentColumnDetails.CSVPath
            Dim parsed_CSV As New TextFieldParser(CSVPath)
            parsed_CSV.Delimiters = New String() {","}
            parsed_CSV.TextFieldType = FieldType.Delimited
            'Repeat till data ends
            While parsed_CSV.EndOfData = False
                Dim fields = parsed_CSV.ReadFields()
                If blnFirstRow Then
                    'Get indices of X, Y, Rotation and SymbolName
                    XIndex = fields.ToList().IndexOf(ComponentColumnDetails.XColumnName)
                    YIndex = fields.ToList().IndexOf(ComponentColumnDetails.YColumnName)
                    RotationIndex = fields.ToList().IndexOf(ComponentColumnDetails.RotationColumnName)
                    SymbolNameIndex = fields.ToList().IndexOf(ComponentColumnDetails.SymbolName)
                    'Get indices of various Symbol Attributes mentioned in datagrid_component_attributes list in BrewPID_SymbolAttributesForm and store them in SymbolDictionary
                    For Each pair In BrewPID_SymbolAttributesForm.datagrid_component_attributes
                        If Not String.IsNullOrWhiteSpace(pair.Value) Then
                            dict_key = pair.Value
                            dict_value = fields.ToList().IndexOf(dict_key)
                            AttributeDictionaries.SymbolDictonary.Add(dict_key, dict_value)
                        End If
                    Next
                    blnFirstRow = False
                    Continue While
                End If

                'Check if the Symbol name being processed is present in the list of Symbols obtained from the BrewPID_SymbolMappingForm
                If Not BrewPID_SymbolMappingForm.Components_In_DataGrid.Contains(fields(SymbolNameIndex)) Then
                    Continue While
                End If
                'Recheck the existence of Symbol file during processing stage
                If Not File.Exists(MasterMappingFile.MasterMappingDictionary(fields(SymbolNameIndex)).Split(",")(0)) Then
                    WriteLog("This Symbol SPPID file doesn't exists: " + MasterMappingFile.MasterMappingDictionary(fields(SymbolNameIndex)).Split(",")(0))
                    Continue While
                End If
                'Check if X and Y coordinates are null or not
                If (String.IsNullOrWhiteSpace(fields(XIndex)) Or (String.IsNullOrWhiteSpace(fields(YIndex))) Or (String.IsNullOrWhiteSpace(fields(RotationIndex)))) Then
                    WriteLog("Coordinate(s) of the component is(are) empty")
                    Continue While
                End If

                'Process the details secured from the data from the CSV and then put them in the Symbol class object
                'Convert rotation from Degrees to Radians (since Intergraph SPPID accepts only radians)
                Symbol.Rotation = CStr((Math.PI / 180) * Val(fields(RotationIndex)))
                'Get proper measurement in metres based upon Grid Density Unit provided by the user in Form1
                If SPPIDGridDetails.GridDensityUnit = "mm" Then
                    Symbol.X = (Math.Ceiling((Scale * Val(fields(XIndex)) * 1000) / SPPIDGridDetails.GridDensity)) * SPPIDGridDetails.GridDensity
                    Symbol.X = CStr(Symbol.X * 0.001)
                    Symbol.Y = (Math.Ceiling((Scale * Val(fields(YIndex)) * 1000) / SPPIDGridDetails.GridDensity)) * SPPIDGridDetails.GridDensity
                    Symbol.Y = CStr(Symbol.Y * 0.001)
                Else
                    Symbol.X = (Math.Ceiling((Scale * Val(fields(XIndex)) * 39.37) / SPPIDGridDetails.GridDensity)) * SPPIDGridDetails.GridDensity
                    Symbol.X = CStr(Symbol.X * 0.0254)
                    Symbol.Y = (Math.Ceiling((Scale * Val(fields(YIndex)) * 39.37) / SPPIDGridDetails.GridDensity)) * SPPIDGridDetails.GridDensity
                    Symbol.Y = CStr(Symbol.Y * 0.0254)
                End If
                'Transfer details of Location and Type to Symbol's global variables
                Symbol.Location = MasterMappingFile.MasterMappingDictionary(fields(SymbolNameIndex)).Split(",")(0)
                Symbol.Type = MasterMappingFile.MasterMappingDictionary(fields(SymbolNameIndex)).Split(",")(1)
                'Transfer attributes to Symbol's AttributeDictionary
                Symbol.AttributeDictionary = New Dictionary(Of String, String)
                For Each pair In AttributeDictionaries.SymbolDictonary
                    Dim key As String = pair.Key
                    Dim value As String
                    If String.IsNullOrWhiteSpace(fields(pair.Value)) Then
                        value = ""
                    Else
                        value = fields(pair.Value)
                    End If
                    Symbol.AttributeDictionary.Add(key, value)
                Next
                'Add all the attributes (including X, Y. Location and Rotation) to Symbols_Parameters list
                Symbol_Parameters = New List(Of Object)
                Symbol_Parameters.Add(Symbol.Location)
                Symbol_Parameters.Add(Symbol.X)
                Symbol_Parameters.Add(Symbol.Y)
                Symbol_Parameters.Add(Symbol.Rotation)
                Symbol_Parameters.Add(Symbol.AttributeDictionary)
                'Adding Symbol_Parameters list to one of the lists in SymbolsList based upon the symbol type
                If (Symbol.Type = "Main Equipment") Then
                    SymbolLists.MainEquipment.Add(Symbol_Parameters)
                ElseIf (Symbol.Type = "Sub Equipment") Then
                    SymbolLists.SubEquipment.Add(Symbol_Parameters)
                ElseIf (Symbol.Type = "Piping Comp") Then
                    SymbolLists.PipingComp.Add(Symbol_Parameters)
                ElseIf (Symbol.Type = "Instrument") Then
                    SymbolLists.Instrument.Add(Symbol_Parameters)
                ElseIf (Symbol.Type = "Label") Then
                    SymbolLists.Label.Add(Symbol_Parameters)
                ElseIf (Symbol.Type = "Design") Then
                    SymbolLists.Design.Add(Symbol_Parameters)
                End If
            End While

        Catch ex As Exception
            WriteLog("Error in 'GetComponentData' subprocess - " + ex.Message)
            MessageBox.Show("An error has occurred. Please refer to the log file for further information.")
            CloseLog()
            BrewPID_MainForm.Close()
            'Throw
        End Try
    End Sub

    ''' <summary>
    ''' 'PlaceMainEquipment' subprocess handles placing of MainEquipment in the SPPID drawing. This function is currently unused and not updated. Refer to PlacePipingComp for updation
    ''' </summary>
    Public Sub PlaceMainEquipment()
        Try
            For Each MainEquipmentData In SymbolLists.MainEquipment
                WriteLog("Placing " + MainEquipmentData(0) + " at X:" + MainEquipmentData(1) + " And Y:" + MainEquipmentData(2) + " coordinates")
                'Placing the Main Equipment
                Dim MainEquipment_symbol As LMSymbol = ObjectPlacment.objplacement.PIDPlaceSymbol(DefinitionFile:=MainEquipmentData(0), X:=Val(MainEquipmentData(1)), Y:=Val(MainEquipmentData(2)), Rotation:=Val(MainEquipmentData(3)))
                'Checking if Symbol is placed or not
                If MainEquipment_symbol Is Nothing Then
                    WriteLog("This " + MainEquipmentData(0) + " not placed at X:" + MainEquipmentData(1) + " and Y:" + MainEquipmentData(2) + " coordinates")
                Else
                    'Getting the symbol from the drawing
                    'Dim MainEquipment As LMEquipment
                    'Dim datasource As LMADataSource = ObjectPlacment.objplacement.PIDDataSource
                    'MainEquipment = datasource.GetEquipment(MainEquipment_symbol.ModelItemID)
                    'WriteLog("Trying to set item tag of Main Equipment to : " + MainEquipmentData(4))
                    'MainEquipment.Attributes("itemtag").Value = MainEquipmentData(4)
                    'MainEquipment.ItemTag = MainEquipmentData(4)
                    'MainEquipment.Commit()
                    'WriteLog("Item tag of Main Equipment is set to : " + MainEquipment.Attributes("itemtag").Value)
                    SymbolLists.MainEquipmentSymbol.Add(MainEquipment_symbol)
                End If
            Next
        Catch ex As Exception
            WriteLog("Error in the 'PlaceMainEquipment' subprocess :" + ex.Message)
            MessageBox.Show("An error has occurred. Please refer to the log file for further information.")
        End Try
    End Sub

    ''' <summary>
    ''' 'PlaceSubEquipment' subprocess handles placing of SubEquipment in the SPPID drawing. This function is currently unused and not updated. Refer to PlacePipingComp for updation
    ''' </summary>
    Public Sub PlaceSubEquipment()
        Try
            For Each SubEquipmentData In SymbolLists.SubEquipment
                Dim nearest_symbol As LMSymbol
                Dim min_distance_squared As Double = 100
                WriteLog("Placing " + SubEquipmentData(0) + " at X:" + SubEquipmentData(1) + " And Y:" + SubEquipmentData(2) + " coordinates")
                For Each MainEquipmentSymbol In SymbolLists.MainEquipmentSymbol
                    Dim distance_squared = ((MainEquipmentSymbol.XCoordinate - Val(SubEquipmentData(1))) ^ 2) + ((MainEquipmentSymbol.YCoordinate - Val(SubEquipmentData(2))) ^ 2)
                    If (distance_squared < min_distance_squared) Then
                        min_distance_squared = distance_squared
                        nearest_symbol = MainEquipmentSymbol
                    End If
                Next
                Dim SubEquipment_symbol As LMSymbol = ObjectPlacment.objplacement.PIDPlaceSymbol(DefinitionFile:=SubEquipmentData(0), X:=Val(SubEquipmentData(1)), Y:=Val(SubEquipmentData(2)), Rotation:=Val(SubEquipmentData(3)), TargetItem:=nearest_symbol.AsLMRepresentation)
                If SubEquipment_symbol Is Nothing Then
                    WriteLog("This " + SubEquipmentData(0) + " not placed at X:" + SubEquipmentData(1) + " and Y:" + SubEquipmentData(2) + " coordinates")
                Else
                    'Dim SubEquipment As LMEquipment
                    'Dim datasource As LMADataSource = ObjectPlacment.objplacement.PIDDataSource
                    'SubEquipment = datasource.GetEquipment(SubEquipment_symbol.ModelItemID)
                    'WriteLog("Trying to set item tag of Sub Equipment to : " + SubEquipmentData(4))
                    'SubEquipment.Attributes("itemtag").Value = SubEquipmentData(4)
                    'SubEquipment.ItemTag = SubEquipmentData(4)
                    'SubEquipment.Commit()
                    'WriteLog("Item tag of Sub Equipment is set to : " + SubEquipment.Attributes("itemtag").Value)
                End If
            Next
        Catch ex As Exception
            WriteLog("Error in 'PlaceSubEquipment' subprocess :" + ex.Message)
            MessageBox.Show("An error has occurred. Please refer to the log file for further information.")
        End Try
    End Sub

    ''' <summary>
    ''' 'PlacePipingLines' subprocess deals with getting the pipeline data based on the Column names from BrewPID_MainForm
    ''' </summary>
    ''' <summary>
    ''' 'PlacePipingLines' subprocess deals with getting the pipeline data based on the Column names from BrewPID_MainForm
    ''' </summary>
    Public Sub getPipingData()
        Try
            Dim X1Index As Integer
            Dim X2Index As Integer
            Dim Y1Index As Integer
            Dim Y2Index As Integer
            Dim PipelineNameIndex As Integer
            Dim TypeIndex As Integer
            Dim Scale As Double
            Dim dict_key As String
            Dim dict_value As Integer
            Dim blnFirstRow As Boolean = True
            'Dim PipingLine_Parameters As List(Of Object)
            Dim line_dictionary As New Dictionary(Of String, List(Of List(Of Object)))
            'Dim pair As KeyValuePair(Of String, Integer)
            'Scale appropriately to metres based on the unit provided in the Form1
            If (LineColumnDetails.Unit = "inches") Then
                Scale = 0.0254
            Else
                Scale = 0.001
            End If

            WriteLog("Processing pipeline file : " + LineColumnDetails.CSVPath)
            'Parse the CSV
            Dim CSVPath = LineColumnDetails.CSVPath
            Dim parsed_CSV As New TextFieldParser(CSVPath)
            parsed_CSV.Delimiters = New String() {","}
            parsed_CSV.TextFieldType = FieldType.Delimited
            'Repeat till end of data
            While parsed_CSV.EndOfData = False
                Dim fields = parsed_CSV.ReadFields()
                If blnFirstRow Then
                    'Get indices of X1, X2, Y1 and Y2 from the first row of the parsed Pipeline CSV
                    X1Index = fields.ToList().IndexOf(LineColumnDetails.X1ColumnName)
                    Y1Index = fields.ToList().IndexOf(LineColumnDetails.Y1ColumnName)
                    X2Index = fields.ToList().IndexOf(LineColumnDetails.X2ColumnName)
                    Y2Index = fields.ToList().IndexOf(LineColumnDetails.Y2ColumnName)
                    PipelineNameIndex = fields.ToList().IndexOf(LineColumnDetails.PipelineName)
                    Dim obj As BrewPID_SymbolAttributesForm = New BrewPID_SymbolAttributesForm
                    'obj.datagrid_pipeline_attributes
                    If BrewPID_SymbolAttributesForm.datagrid_pipeline_attributes IsNot Nothing Then
                        'Get the indices of all the pipeline attributes added by the user in datagrid_pipeline_attributes in PipelineAttributesForm and add these attibutes and indices to the PipingLineDictionary
                        For Each pair In BrewPID_SymbolAttributesForm.datagrid_pipeline_attributes
                            If Not String.IsNullOrWhiteSpace(pair.Value) Then
                                dict_key = pair.Value
                                dict_value = fields.ToList().IndexOf(dict_key)
                                AttributeDictionaries.PipelineDictonary.Add(dict_key, dict_value)
                            End If
                        Next
                    End If
                    'Get the indices of all the pipeline attributes added by the user in datagrid_pipeline_attributes in PipelineAttributesForm and add these attibutes and indices to the PipingLineDictionary
                    'For Each pair In BrewPID_SymbolAttributesForm.datagrid_pipeline_attributes
                    'If Not String.IsNullOrWhiteSpace(pair.Value) Then
                    'dict_key = pair.Value
                    'dict_value = fields.ToList().IndexOf(dict_key)
                    'AttributeDictionaries.PipelineDictonary.Add(dict_key, dict_value)
                    'End If
                    'Next
                    blnFirstRow = False
                    Continue While
                End If
                'Check if the Pipeline name being processed is present in the list of Pipelines obtained from the BrewPID_SymbolMappingForm
                If Not BrewPID_SymbolMappingForm.Pipelines_In_DataGrid.Contains(fields(PipelineNameIndex)) Then
                    Continue While
                End If
                'Recheck during processing whether Pipeline CSV exists
                If (Not File.Exists(MasterMappingFile.MasterMappingDictionary(fields(PipelineNameIndex)).Split(",")(0))) Then
                    WriteLog("This Pipeline SPPID file doesn't exists: " + MasterMappingFile.MasterMappingDictionary(fields(PipelineNameIndex)).Split(",")(0))
                    Continue While
                End If
                'Check if the required parameters are present in  the CSV row
                If (String.IsNullOrWhiteSpace(fields(X1Index)) Or (String.IsNullOrWhiteSpace(fields(Y1Index))) Or (String.IsNullOrWhiteSpace(fields(X2Index))) Or (String.IsNullOrWhiteSpace(fields(Y2Index)))) Then
                    WriteLog("Coordinate(s) of the Pipeline is(are) empty")
                    Continue While
                End If

                'Transfer details of X1, Y1, X2, Y2, Location, and Type to PipingLine's global variables
                If SPPIDGridDetails.GridDensityUnit = "mm" Then
                    PipingLine.X1 = CStr((Math.Ceiling((Scale * Val(fields(X1Index)) * 1000) / SPPIDGridDetails.GridDensity)) * SPPIDGridDetails.GridDensity * 0.001)
                    PipingLine.Y1 = CStr((Math.Ceiling((Scale * Val(fields(Y1Index)) * 1000) / SPPIDGridDetails.GridDensity)) * SPPIDGridDetails.GridDensity * 0.001)
                    PipingLine.X2 = CStr((Math.Ceiling((Scale * Val(fields(X2Index)) * 1000) / SPPIDGridDetails.GridDensity)) * SPPIDGridDetails.GridDensity * 0.001)
                    PipingLine.Y2 = CStr((Math.Ceiling((Scale * Val(fields(Y2Index)) * 1000) / SPPIDGridDetails.GridDensity)) * SPPIDGridDetails.GridDensity * 0.001)
                Else
                    PipingLine.X1 = CStr((Math.Ceiling((Scale * Val(fields(X1Index)) * 39.37) / SPPIDGridDetails.GridDensity)) * SPPIDGridDetails.GridDensity * 0.0254)
                    PipingLine.Y1 = CStr((Math.Ceiling((Scale * Val(fields(Y1Index)) * 39.37) / SPPIDGridDetails.GridDensity)) * SPPIDGridDetails.GridDensity * 0.0254)
                    PipingLine.X2 = CStr((Math.Ceiling((Scale * Val(fields(X2Index)) * 39.37) / SPPIDGridDetails.GridDensity)) * SPPIDGridDetails.GridDensity * 0.0254)
                    PipingLine.Y2 = CStr((Math.Ceiling((Scale * Val(fields(Y2Index)) * 39.37) / SPPIDGridDetails.GridDensity)) * SPPIDGridDetails.GridDensity * 0.0254)
                End If

                PipingLine.Location = MasterMappingFile.MasterMappingDictionary(fields(PipelineNameIndex)).Split(",")(0)
                PipingLine.Type = fields(TypeIndex)

                'Transfer the attributes from AttributeDictionaries.PipelineDictonary to PipingLine.AttributeDictionary
                PipingLine.AttributeDictionary = New Dictionary(Of String, String)
                For Each pair In AttributeDictionaries.PipelineDictonary
                    Dim key As String = pair.Key
                    Dim value As String
                    If String.IsNullOrWhiteSpace(fields(pair.Value)) Then
                        value = ""
                    Else
                        value = fields(pair.Value)
                    End If
                    PipingLine.AttributeDictionary.Add(key, value)
                Next
                'Call the 'PlacePipeline' subprocess
                PlacePipeline()

                'AddtoPipingLineParameters(fields)
            End While
            'Call the MergeAndPlacePipingLines subprocess
            'MergeAndPlacePipingLines(line_dictionary)
        Catch ex As Exception
            WriteLog("Error in 'getPipingData' subprocess :" + ex.Message)
            MessageBox.Show("An error has occurred. Please refer to the log file for further information.")
            CloseLog()
            BrewPID_MainForm.Close()
        End Try
    End Sub

    ''' <summary>
    ''' 'PlacePipeline' subprocess handles placing of Pipelines on the active SPPID drawing
    ''' </summary>
    Public Sub PlacePipeline()
        Try
            'Try placing the line using PIDPlaceRun
            Dim item As LMAItem = ObjectPlacment.objplacement.PIDCreateItem(PipingLine.Location)
            Dim inputs As PlaceRunInputs = New PlaceRunInputs
            inputs.AddPoint(Val(PipingLine.X1), Val(PipingLine.Y1))
            inputs.AddPoint(Val(PipingLine.X2), Val(PipingLine.Y2))
            Dim conn2 As LMConnector = ObjectPlacment.objplacement.PIDPlaceRun(item, inputs)

            If conn2 Is Nothing Then
                WriteLog("This " + PipingLine.Location + " not placed at X1,Y1 : " + PipingLine.X1 + PipingLine.Y1 + " and X2,Y2 : " + PipingLine.X2 + PipingLine.Y2 + " coordinates")
            Else
                Dim DataSource As New LMADataSource
                Dim objPiperun As LMPipeRun
                objPiperun = DataSource.GetPipeRun(conn2.ModelItemID)
                'Call SetAttributes subprocess
                SetAttributes(objPiperun, PipingLine.AttributeDictionary)
                'Call the ReleaseCOMObjects subprocess
                ReleaseCOMObjects(conn2, objPiperun, DataSource)
            End If
        Catch ex As Exception
            'Create a new Placement object since the old Placement object gets corrupted in case the try block does not run, and so the old Placement object cannot be used further
            WriteLog("Error placing using PIDPlacerun at X1 :" + PipingLine.X1 + ", Y1 : " + PipingLine.Y1 + ", X2 : " + PipingLine.X2 + ", Y2 : " + PipingLine.Y2 + " :- " + ex.Message + ". Creating fresh objplacement")
            ObjectPlacment.objplacement = New Placement
        End Try
    End Sub

    ''' <summary>
    ''' 'AddtoPipingLineParameters' subprocess places the relevant data related to the Piping line in the PipingLine_Parameters list and line_dictionary
    ''' </summary>
    ''' <param name="fields"></param>
    Public Sub AddtoPipingLineParameters(fields)
        Dim PipingLine_Parameters As List(Of Object) = New List(Of Object)
        Dim line_dictionary As New Dictionary(Of String, List(Of List(Of Object)))
        'Scale and Add X1, Y1, X2, Y2 to PipingLine_Parameters
        If (LineColumnDetails.Unit = "inches") Then
            PipingLine_Parameters.Add(CStr(Val(PipingLine.X1) * 25.4))
            PipingLine_Parameters.Add(CStr(Val(PipingLine.Y1) * 25.4))
            PipingLine_Parameters.Add(CStr(Val(PipingLine.X2) * 25.4))
            PipingLine_Parameters.Add(CStr(Val(PipingLine.Y2) * 25.4))
        Else
            PipingLine_Parameters.Add(PipingLine.X1)
            PipingLine_Parameters.Add(PipingLine.Y1)
            PipingLine_Parameters.Add(PipingLine.X2)
            PipingLine_Parameters.Add(PipingLine.Y2)
        End If

        For Each pair In AttributeDictionaries.PipelineDictonary
            Dim key As String = pair.Key
            Dim value As String
            If String.IsNullOrWhiteSpace(fields(pair.Value)) Then
                value = ""
            Else
                value = fields(pair.Value)
            End If
            PipingLine.AttributeDictionary.Add(key, value)
        Next
        PipingLine_Parameters.Add(PipingLine.AttributeDictionary)
        'Segregate the Pipinglines into various categories based upon their file location
        If line_dictionary.ContainsKey(PipingLine.Location) Then
            line_dictionary.Item(PipingLine.Location).Add(PipingLine_Parameters)
        Else
            Dim Piping_Line_List As New List(Of List(Of Object))
            Piping_Line_List.Add(PipingLine_Parameters)
            line_dictionary.Add(PipingLine.Location, Piping_Line_List)
        End If
    End Sub
    ''' <summary>
    ''' 'MergeAndPlacePipingLines' subprocess performs merging of lines by calling mergeLines function and places all the lines on the SPPID drawings
    ''' </summary>
    ''' <param name="line_dictionary"></param>
    Public Sub MergeAndPlacePipingLines(line_dictionary)
        Try
            Dim NewGridDensity As Double
            If SPPIDGridDetails.GridDensityUnit = "mm" Then
                NewGridDensity = Val(SPPIDGridDetails.GridDensity)
            Else
                NewGridDensity = Val(SPPIDGridDetails.GridDensity) * 25.4
            End If

            Dim another_pair As KeyValuePair(Of String, List(Of List(Of Object)))
            'Access each line_dictionary
            For Each another_pair In line_dictionary
                'Merge lines by calling mergeLines function
                Dim lines_merged As List(Of List(Of Double)) = mergeLines(another_pair.Value, NewGridDensity, CInt(SPPIDGridDetails.GridIndex), "mm")
                'Check if the lines_merged returns Nothing (this happens in case all the lines are slant or if the lines are smaller than one grid) 
                If IsNothing(lines_merged) Then
                    Continue For
                End If
                'Iterate through each line in lines_merged
                For Each line_list In lines_merged
                    Dim points(0 To 3) As Double
                    points(0) = line_list(0) * 0.001
                    points(1) = line_list(1) * 0.001
                    points(2) = line_list(2) * 0.001
                    points(3) = line_list(3) * 0.001
                    WriteLog("Placing pipeline : " + another_pair.Key + " at X1 :" + CStr(points(0)) + ", Y1 : " + CStr(points(1)) + ", X2 : " + CStr(points(2)) + ", Y2 : " + CStr(points(3)))
                    'Try placing the line using PIDPlaceRun
                    Try
                        Dim item As LMAItem = ObjectPlacment.objplacement.PIDCreateItem(another_pair.Key)
                        Dim inputs As PlaceRunInputs = New PlaceRunInputs
                        inputs.AddPoint(points(0), points(1))
                        inputs.AddPoint(points(2), points(3))
                        Dim conn2 As LMConnector = ObjectPlacment.objplacement.PIDPlaceRun(item, inputs)
                    Catch ex As Exception
                        'Create a new Placement object since the old Placement object gets corrupted in case the try block does not run, and so the old Placement object cannot be used further
                        WriteLog("Error placing using PIDPlacerun at X1 :" + CStr(points(0)) + ", Y1 : " + CStr(points(1)) + ", X2 : " + CStr(points(2)) + ", Y2 : " + CStr(points(3)) + " :- " + ex.Message + ". Creating fresh objplacement")
                        ObjectPlacment.objplacement = New Placement
                    End Try
                    WriteLog("Successfully placed pipeline : " + another_pair.Key + " at X1 :" + CStr(points(0)) + ", Y1 : " + CStr(points(1)) + ", X2 : " + CStr(points(2)) + ", Y2 : " + CStr(points(3)))
                Next
            Next
        Catch ex As Exception
            WriteLog("Error in 'MergeAndPlacePipingLines' subprocess :" + ex.Message)
            MessageBox.Show("An error has occurred. Please refer to the log file for further information.")
            CloseLog()
            BrewPID_MainForm.Close()
        End Try

    End Sub

    ''' <summary>
    ''' 'mergeLines' function processes the line data from an input CSV file and returns it as a list. No documentation is present. Developed by Kartik Gokte
    ''' </summary>
    ''' <param name="lineCoordinates"> A list containing coordinates of line segments</param>
    ''' <param name="GridDensity">Unit size of the grid</param>
    ''' <param name="GridValue">Index of the grid</param>
    ''' <param name="unit">Unit of measurement to be used (can be <c>inches</c> or <c>mm</c>)</param>
    ''' <returns>List of coordinates of line segments</returns>

    Public Function mergeLines(ByVal lineCoordinates As List(Of List(Of Object)), ByVal GridDensity As Double, ByVal GridValue As Integer, ByVal unit As String) As List(Of List(Of Double))
        Try

            Dim coordinates As List(Of List(Of Double)) = New List(Of List(Of Double))

            For Each line As List(Of Object) In lineCoordinates
                Dim x1 As Double
                Dim y1 As Double
                Dim x2 As Double
                Dim y2 As Double

                If Double.TryParse(line(0), x1) = False Or Double.TryParse(line(1), y1) = False Or Double.TryParse(line(2), x2) = False Or Double.TryParse(line(3), y2) = False Then
                    Continue For
                End If

                Dim dline As List(Of Double) = New List(Of Double)
                dline.Add(x1)
                dline.Add(y1)
                dline.Add(x2)
                dline.Add(y2)

                coordinates.Add(dline)
            Next

            Dim processedlines As List(Of List(Of Double)) = New List(Of List(Of Double))
            For Each line As List(Of Double) In coordinates
                Dim x1 = line(0)
                Dim y1 = line(1)
                Dim x2 = line(2)
                Dim y2 = line(3)
                Dim px1 As Double
                Dim px2 As Double
                Dim py1 As Double
                Dim py2 As Double
                px1 = gridmove(x1, GridDensity)
                px2 = gridmove(x2, GridDensity)
                py1 = gridmove(y1, GridDensity)
                py2 = gridmove(y2, GridDensity)

                Dim processedline As List(Of Double) = New List(Of Double)
                processedline.Add(px1)
                processedline.Add(py1)
                processedline.Add(px2)
                processedline.Add(py2)
                processedlines.Add(processedline)
            Next

            Dim horizontal As List(Of List(Of Double)) = New List(Of List(Of Double))
            Dim vertical As List(Of List(Of Double)) = New List(Of List(Of Double))
            Dim slant As List(Of List(Of Double)) = New List(Of List(Of Double))

            For Each line As List(Of Double) In processedlines
                If (line(0) = line(2) And line(1) = line(3)) Then
                    Continue For
                ElseIf line(0) = line(2) Then
                    vertical.Add(line)
                ElseIf line(1) = line(3) Then
                    horizontal.Add(line)
                Else
                    slant.Add(line)
                End If
            Next


            Dim finalvert = getVerticalLines(vertical, GridDensity)
            Dim finalhoriz = getHorizontallines(horizontal, GridDensity)
            If (IsNothing(finalvert) = True And IsNothing(finalhoriz) = False) Then
                Return finalhoriz
            ElseIf (IsNothing(finalvert) = False And IsNothing(finalhoriz) = True) Then
                Return finalvert
            ElseIf (IsNothing(finalvert) = True And IsNothing(finalhoriz) = True) Then
                Return Nothing
            End If
            Dim combined As New List(Of List(Of Double))(finalvert.Concat(finalhoriz))
            Return combined

        Catch ex As Exception
            WriteLog("Error in 'mergelines' function :" + ex.Message)
            MessageBox.Show("An error has occurred. Please refer to the log file for further information.")
            CloseLog()
            BrewPID_MainForm.Close()
        End Try
        Return Nothing
    End Function

    ''' <summary>
    ''' 'getHorizontallines' function gets horizontal lines. Developed by Kartik Gokte. No Documentation.
    ''' </summary>
    ''' <param name="horiz">List of coordinates of the lines</param>
    ''' <returns>List containing the merged lines</returns>
    Private Function getHorizontallines(ByVal horiz As List(Of List(Of Double)), ByVal GridDensity As Double) As List(Of List(Of Double))
        If (horiz.Count = 0) Then
            Return Nothing
        End If

        For Each line As List(Of Double) In horiz
            If line(0) > line(2) Then
                Dim temp = line(0)
                line(0) = line(2)
                line(2) = temp
            End If
        Next

        horiz.Sort(Function(x, y) New sortutils("x").Compare(x, y))

        Dim horizret As List(Of List(Of Double)) = New List(Of List(Of Double))
        horizret.Add(horiz(0))
        Dim idx = 0
        For i As Integer = 1 To horiz.Count - 1
            If (horizret(idx)(1) = horiz(i)(1)) Then
                If (horiz(i)(0) - horizret(idx)(2) <= GridDensity) Then
                    horizret(idx)(0) = Math.Min(horizret(idx)(0), horiz(i)(0))
                    horizret(idx)(2) = Math.Max(horizret(idx)(2), horiz(i)(2))
                Else
                    horizret.Add(horiz(i))
                    idx += 1
                End If
            Else
                horizret.Add(horiz(i))
                idx += 1
            End If
        Next
        Return horizret
    End Function

    ''' <summary>
    ''' 'getVerticalLines' function gets vertical lines. Developed by Kartik Gokte. No documentation.
    ''' </summary>
    ''' <param name="vert">List containing the coordinates of the lines</param>
    ''' <returns>A list containing the merged lines</returns>
    Private Function getVerticalLines(ByVal vert As List(Of List(Of Double)), ByVal GridDensity As Double) As List(Of List(Of Double))
        If vert.Count = 0 Then
            Return Nothing
        End If
        For Each line As List(Of Double) In vert
            If line(1) > line(3) Then
                Dim temp = line(1)
                line(1) = line(3)
                line(3) = temp
            End If
        Next

        vert.Sort(Function(x, y) New sortutils("y").Compare(x, y))

        Dim vertret As List(Of List(Of Double)) = New List(Of List(Of Double))
        vertret.Add(vert(0))
        Dim idx = 0
        For i As Integer = 1 To vert.Count - 1
            If (vertret(idx)(0) = vert(i)(0)) Then
                If (vert(i)(1) - vertret(idx)(3) <= GridDensity) Then
                    vertret(idx)(1) = Math.Min(vertret(idx)(1), vert(i)(1))
                    vertret(idx)(3) = Math.Max(vertret(idx)(3), vert(i)(3))
                Else
                    vertret.Add(vert(i))
                    idx += 1
                End If
            Else
                vertret.Add(vert(i))
                idx += 1
            End If
        Next
        Return vertret
    End Function

    ''' <summary>
    ''' 'PlaceInstruments' subprocess handles placing of instruments in the SPPID drawing
    ''' </summary>
    Public Sub PlaceInstruments()
        Try
            For Each InstrumentData In SymbolLists.Instrument
                WriteLog("Placing " + InstrumentData(0) + " at X:" + InstrumentData(1) + " And Y:" + InstrumentData(2) + " coordinates with Rotation: " + InstrumentData(3))
                'Place Instrument_symbol in SPPID
                Dim Instrument_symbol As LMSymbol = ObjectPlacment.objplacement.PIDPlaceSymbol(DefinitionFile:=InstrumentData(0), X:=Val(InstrumentData(1)), Y:=Val(InstrumentData(2)), Rotation:=Val(InstrumentData(3)))
                'Check if Instrument_symbol is not placed
                If Instrument_symbol Is Nothing Then
                    WriteLog("This " + InstrumentData(0) + " not placed at X:" + InstrumentData(1) + " and Y:" + InstrumentData(2) + " coordinates")
                Else
                    'Get Instrument from the SPPID drawing
                    Dim Instrument As LMInstrument
                    Dim datasource As LMADataSource = ObjectPlacment.objplacement.PIDDataSource
                    Instrument = datasource.GetInstrument(Instrument_symbol.ModelItemID)
                    'Call the SetAttributes subprocess
                    SetAttributes(Instrument, InstrumentData(4))
                    'Call the ReleaseCOMObjects subprocess
                    ReleaseCOMObjects(Instrument_symbol, Instrument, datasource)
                End If
            Next
        Catch ex As Exception
            WriteLog("Error in 'PlaceInstruments' subprocess : " + ex.Message)
            'MessageBox.Show("An error has occurred. Please refer to the log file for further information.")
        End Try
    End Sub

    ''' <summary>
    ''' 'SetAttributes' subprocess handles the attribute setting for symbols
    ''' </summary>
    ''' <param name="Symbol"></param>
    ''' <param name="AttributeDataDictionary"></param>
    Public Sub SetAttributes(Symbol, AttributeDataDictionary)
        Try
            WriteLog("Setting attributes ")
            'Set attributes for the instrument 
            For Each pair In AttributeDataDictionary
                'Check if the attribute name is not empty
                If Not String.IsNullOrWhiteSpace(pair.key) Then
                    Try
                        'Convert the attribute name to lower case and remove spaces
                        Symbol.Attributes(pair.key.Replace(" ", "").ToLower()).Value = pair.value
                        'Check if the required attribute has been assigned
                        If String.IsNullOrWhiteSpace(Symbol.Attributes(pair.key.Replace(" ", "").ToLower()).Value) Then
                            WriteLog("Could not place attribute " + pair.key.Replace(" ", "").ToLower())
                        Else
                            'Declare that the attribute value has been correctly entered
                            WriteLog("Attribute " + pair.key.Replace(" ", "").ToLower() + "set as " + Symbol.Attributes(pair.key.Replace(" ", "").ToLower()).Value)
                        End If
                    Catch ex As Exception
                        WriteLog("Error while placing attribute " + pair.key.Replace(" ", "").ToLower() + " : " + ex.Message)
                    End Try
                End If
            Next
            'Save the details of instrument to SPPID
            Symbol.Commit()
        Catch ex As Exception
            WriteLog("Error in 'SetAttributes' subprocess : " + ex.Message)
            'MessageBox.Show("An error has occurred. Please refer to the log file for further information.")
        End Try
    End Sub

    ''' <summary>
    ''' 'PlacePipingComp' subprocess handles placing of piping comps in the SPPID drawing
    ''' </summary>
    Public Sub PlacePipingComp()
        Try
            For Each PipingCompData In SymbolLists.PipingComp
                WriteLog("Placing " + PipingCompData(0) + " at X:" + PipingCompData(1) + " And Y:" + PipingCompData(2) + " coordinates with Rotation: " + PipingCompData(3))
                'Place PipingComp_symbol in SPPID
                Dim PipingComp_symbol As LMSymbol = ObjectPlacment.objplacement.PIDPlaceSymbol(DefinitionFile:=PipingCompData(0), X:=Val(PipingCompData(1)), Y:=Val(PipingCompData(2)), Rotation:=Val(PipingCompData(3)))
                'Check if PipingComp_symbol is not placed
                If PipingComp_symbol Is Nothing Then
                    WriteLog("This " + PipingCompData(0) + " not placed at X:" + PipingCompData(1) + " and Y:" + PipingCompData(2) + " coordinates")
                Else
                    'Get PipingComp from the SPPID drawing
                    Dim PipingComp As LMPipingComp
                    Dim datasource As LMADataSource = ObjectPlacment.objplacement.PIDDataSource
                    PipingComp = datasource.GetPipingComp(PipingComp_symbol.ModelItemID)
                    'Call the SetAttributes subprocess
                    SetAttributes(PipingComp, PipingCompData(4))
                    'Call the ReleaseCOMObjects subprocess
                    ReleaseCOMObjects(PipingComp_symbol, PipingComp, datasource)
                End If
            Next
        Catch ex As Exception
            WriteLog("Error in 'PlacePipingcomp' subprocess : " + ex.Message)
            'MessageBox.Show("An error has occurred. Please refer to the log file for further information.")
        End Try
    End Sub


    ''' <summary>
    ''' 'gridmove' is an utility function to normalize coordinates to the grid. Written by Kartik Gokte. No documentation.
    ''' </summary>
    ''' <param name="point"></param>
    ''' <param name="GridDensity"></param>
    ''' <returns></returns>
    Private Function gridmove(ByVal point As Double, ByVal GridDensity As Double) As Double
        If (point Mod GridDensity) <> 0 Then
            Return (GridDensity * Math.Ceiling(point / GridDensity))
        Else
            Return point
        End If
    End Function

    ''' <summary>
    ''' 'WriteLog' subprocess is for writing in the log file. Written by Pankaj. 
    ''' </summary>
    ''' <param name="pstrMessage"></param>
    Public Sub WriteLog(pstrMessage As String)
        Try
            PropStreamWriterObject.WriteLine(pstrMessage)
        Catch ex As Exception
            'Throw
        End Try
    End Sub

    ''' <summary>
    ''' 'CloseLog' subprocess is for closing the log file. Written by Pankaj.
    ''' </summary>
    Public Sub CloseLog()
        Try
            PropStreamWriterObject.Close()
        Catch ex As Exception
            'Throw
        End Try
    End Sub

    ''' <summary>
    ''' 'ReleaseCOMObjects' function is for releasing all SPPID objects. Written by Pankaj.
    ''' </summary>
    ''' <param name="objVars"></param>
    ''' <returns>intNewRefCount, Integer</returns>
    Public Function ReleaseCOMObjects(ByVal ParamArray objVars() As Object) As Integer
        Dim intNewRefCount As Integer = 0 ' initialize the return variable
        For Each obj As Object In objVars
            ' if obj is Nothing, then this if will "short circuit" with the AndAlso operator and IsComObject will not be evaluated
            If Not IsNothing(obj) AndAlso Runtime.InteropServices.Marshal.IsComObject(obj) Then
                intNewRefCount = intNewRefCount + Runtime.InteropServices.Marshal.FinalReleaseComObject(obj)
            End If
        Next
        Return intNewRefCount
    End Function

End Module