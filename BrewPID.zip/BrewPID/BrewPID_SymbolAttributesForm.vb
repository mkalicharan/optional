﻿Imports System.IO

Public Class BrewPID_SymbolAttributesForm

    Dim button_used As Boolean = False
    Public pipeline_submit_button_used As Boolean
    Public component_submit_button_used As Boolean
    Dim attribute_number As Integer
    Dim attributes_in_SymbolAttributeMapping As Dictionary(Of String, String) = New Dictionary(Of String, String)
    Public datagrid_component_attributes As Dictionary(Of String, String)
    Public datagrid_pipeline_attributes As Dictionary(Of String, String)

    ''' <summary>
    ''' 'Button_Add_Atrribute_Click' subprocess defines what happens after Button_Add_Attribute button is clicked in BrewPID_SymbolAttributesForm
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Button_Add_Atrribute_Click(sender As Object, e As EventArgs) Handles Button_Add_Atrribute.Click
        Try
            'Check if the button_used is True or False
            If Not button_used Then
                Dim file_path As String
                'Check which tab of the TabControl_BrewPID of the BrewPID_MainForm is active and choose the file_path accordingly
                If BrewPID_MainForm.TabControl_BrewPID.SelectedIndex = 0 Then
                    file_path = BrewPID_MainForm.Component_Text_Path.Text
                Else
                    file_path = BrewPID_MainForm.Pipeline_Text_Path.Text
                End If
                'Check if the Symbol_Attribute_Mapping.csv is empty or not
                If File.ReadAllText(Path.GetDirectoryName(file_path) + "\Symbol_Attribute_Mapping.csv").Length <> 0 Then
                    'Set the attribute_number to be one more than the maximum attribute number from the CSV, so as to have unique attribute numbers
                    Dim maximum_attribute_number As Integer = 0
                    Dim attributes_in_mapping_file As List(Of String) = File.ReadAllLines(Path.GetDirectoryName(file_path) + "\Symbol_Attribute_Mapping.csv").ToList()
                    For Each single_row In attributes_in_mapping_file
                        If (CInt(single_row.Split(",")(0)) > maximum_attribute_number) Then
                            maximum_attribute_number = CInt(single_row.Split(",")(0))
                        End If
                    Next
                    attribute_number = maximum_attribute_number + 1
                Else
                    'Set attribute_number to 1 in case the Symbol_Attribute_Mapping.csv is empty
                    attribute_number = 1
                End If
                'Set the button_used as True as 'Add_Attribute' button has been used for the first time
                button_used = True
            Else
                'Increment attribute_number after each click of 'Add_Attribute' button
                attribute_number = attribute_number + 1
            End If

            Dim row As ArrayList = New ArrayList
            'Add attribute_number in the first column of Symbol_Attribute_Datagrid and add the row
            row.Add(CStr(attribute_number))
            Symbol_Attribute_Datagrid.Rows.Add(row.ToArray())
        Catch ex As Exception
            WriteLog("Error in 'Button_Add_Atrribute_Click' subprocess : " + ex.Message)
            PropStreamWriterObject.Close()
            BrewPID_MainForm.Close()
        End Try

    End Sub

    ''' <summary>
    ''' 'Button_Submit_Click' subprocess defines what happens after Button_Submit button is clicked in BrewPID_SymbolAttributesForm
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Button_Submit_Click(sender As Object, e As EventArgs) Handles Button_Submit.Click
        Try
            Dim file_path As String
            'Check which tab of the TabControl_BrewPID of the BrewPID_MainForm is active and choose the file_path accordingly and make the submit_button boolean as True
            If BrewPID_MainForm.TabControl_BrewPID.SelectedIndex = 0 Then
                file_path = BrewPID_MainForm.Component_Text_Path.Text
                datagrid_component_attributes = New Dictionary(Of String, String)
                component_submit_button_used = True
            Else
                file_path = BrewPID_MainForm.Pipeline_Text_Path.Text
                datagrid_pipeline_attributes = New Dictionary(Of String, String)
                pipeline_submit_button_used = True
            End If
            Dim attribute_list As New List(Of String)
            'Check if the Symbol_Attribute_Mapping.csv is empty 
            If File.ReadAllText(Path.GetDirectoryName(file_path) + "\Symbol_Attribute_Mapping.csv").Length = 0 Then
                'Add all the non empty attributes from the Symbol_Attribute_Datagrid to the attribute_list
                For datagrid_row_index = 0 To (Symbol_Attribute_Datagrid.Rows.Count - 1)
                    If Not String.IsNullOrWhiteSpace(Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(1).Value) Then
                        attribute_list.Add(Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(0).Value & "," & Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(1).Value)
                    End If
                    'Check which tab of the TabControl_BrewPID of the BrewPID_MainForm is active and choose the rows of the Symbol_Attribute_Datagrid to datagrid_component_attributes or datagrid_pipeline_attributes accordingly
                    If BrewPID_MainForm.TabControl_BrewPID.SelectedIndex = 0 Then
                        datagrid_component_attributes.Add(Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(0).Value, Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(1).Value)
                    Else
                        datagrid_pipeline_attributes.Add(Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(0).Value, Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(1).Value)
                    End If
                Next
                'Convert the attribute_list to the new Symbol_Attribute_mapping.csv
                File.WriteAllLines((Path.GetDirectoryName(file_path) + "\Symbol_Attribute_Mapping.csv"), attribute_list.ToArray())
                'Check if the Symbol_Attribute_Mapping.csv is not empty 
            ElseIf File.ReadAllText(Path.GetDirectoryName(file_path) + "\Symbol_Attribute_Mapping.csv").Length <> 0 Then
                Dim different_attributes As New List(Of String)
                'Convert the Symbol_Attribute_Mapping.csv to the attributes_in_mapping_file list
                Dim attributes_in_mapping_file As List(Of String) = File.ReadAllLines(Path.GetDirectoryName(file_path) + "\Symbol_Attribute_Mapping.csv").ToList()
                'Store the list of all attribute numbers using the attributes_in_mapping_file list 
                Dim attribute_number_list As New List(Of String)
                For Each single_row In attributes_in_mapping_file
                    attribute_number_list.Add(single_row.Split(",")(0))
                Next
                'Iterate through every row of the Symbol_Attribute_Datagrid
                For datagrid_row_index = 0 To (Symbol_Attribute_Datagrid.Rows.Count - 1)
                    'Check which tab of the TabControl_BrewPID of the BrewPID_MainForm is active and choose the rows of the Symbol_Attribute_Datagrid to datagrid_component_attributes or datagrid_pipeline_attributes accordingly
                    If BrewPID_MainForm.TabControl_BrewPID.SelectedIndex = 0 Then
                        datagrid_component_attributes.Add(Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(0).Value, Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(1).Value)
                    Else
                        datagrid_pipeline_attributes.Add(Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(0).Value, Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(1).Value)
                    End If
                    'If the attribute is empty or the attribute_number_list already contains the attribute number of the attriute, add the attribute number and name to the different_attributes dictionary
                    If Not ((attribute_number_list.Contains(Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(0).Value)) Or (String.IsNullOrWhiteSpace(Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(1).Value))) Then
                        different_attributes.Add(Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(0).Value & "," & Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(1).Value)
                    End If
                Next
                'If the different_attributes dictionary is not empty, then append the different_attributes to the Symbol_Attribute_Mapping.csv
                If different_attributes.Count() <> 0 Then
                    File.AppendAllLines(Path.GetDirectoryName(file_path) + "\Symbol_Attribute_Mapping.csv", different_attributes)
                End If
            End If
            Hide()
            'MessageBox.Show(datagrid_component_attributes.Count)
        Catch ex As Exception
            WriteLog("Error in 'Button_Submit_Click' subprocess : " + ex.Message)
            PropStreamWriterObject.Close()
            BrewPID_MainForm.Close()
        End Try

    End Sub

    ''' <summary>
    ''' 'Button_Remove_Attribute_Click' subprocess defines what happens after Button_Remove_Attribute button is clicked in Form3
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Button_Remove_Attribute_Click(sender As Object, e As EventArgs) Handles Button_Remove_Attribute.Click
        Try
            'Remove the rows of Symbol_Attribute_Datagrid which have been selected by the user
            For Each row As DataGridViewRow In Symbol_Attribute_Datagrid.SelectedRows
                Symbol_Attribute_Datagrid.Rows.Remove(row)
            Next
        Catch ex As Exception
            WriteLog("Error in 'Button_Remove_Attribute_Click' subprocess : " + ex.Message)
            PropStreamWriterObject.Close()
            BrewPID_MainForm.Close()
        End Try

    End Sub

    ''' <summary>
    ''' 'Symbol_Attribute_Datagrid_CurrentCellDirtyStateChanged' subprocess defines what happens when the current cell's dirty state gets changed
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Symbol_Attribute_Datagrid_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles Symbol_Attribute_Datagrid.CurrentCellDirtyStateChanged
        Try
            'Check if the Current Cell of the Symbol_Attribute_Datagrid is dirty
            If (Symbol_Attribute_Datagrid.IsCurrentCellDirty) Then
                Symbol_Attribute_Datagrid.CommitEdit(DataGridViewDataErrorContexts.Commit)
                'Add all the attributes present in the rows except the last row of the Symbol_Attribute_Datagrid to current_attributes_in_datagrid list
                Dim current_attributes_in_datagrid As List(Of String) = New List(Of String)
                If Symbol_Attribute_Datagrid.Rows.Count > 1 Then
                    For datagrid_row_index = 0 To (Symbol_Attribute_Datagrid.Rows.Count - 1)
                        If (datagrid_row_index <> Symbol_Attribute_Datagrid.CurrentCell.RowIndex) Then
                            current_attributes_in_datagrid.Add(Symbol_Attribute_Datagrid.Rows(datagrid_row_index).Cells(1).Value)
                        End If
                    Next
                End If
                'Prompt the user in case the attribute entered ny him is already present in the current_attributes_in_datagrid list
                If (current_attributes_in_datagrid.Contains(Symbol_Attribute_Datagrid.CurrentCell.Value) And (Symbol_Attribute_Datagrid.Rows.Count > 1)) Then
                    MessageBox.Show("The attribute '" + Symbol_Attribute_Datagrid.CurrentCell.Value + "' has already been added in the table.")
                    attribute_number = attribute_number + 1
                    Symbol_Attribute_Datagrid.Rows.RemoveAt(Symbol_Attribute_Datagrid.CurrentCell.RowIndex)
                    Dim row As ArrayList = New ArrayList
                    'Add attribute_number in the first column of Symbol_Attribute_Datagrid And add the row
                    row.Add(CStr(attribute_number))
                    Symbol_Attribute_Datagrid.Rows.Add(row.ToArray())
                    'Symbol_Attribute_Datagrid.Rows(Symbol_Attribute_Datagrid.CurrentCell.RowIndex).Cells(1).Value = String.Empty
                    Symbol_Attribute_Datagrid.CommitEdit(DataGridViewDataErrorContexts.Commit)
                    'Check if the attribute entered by thse user is already present in the attributes_in_SymbolAttributeMapping dictionary and assign the attribute number accordingly
                ElseIf attributes_in_SymbolAttributeMapping.ContainsKey(Symbol_Attribute_Datagrid.CurrentCell.Value) Then
                    Symbol_Attribute_Datagrid.Rows(Symbol_Attribute_Datagrid.CurrentCell.RowIndex).Cells(0).Value = attributes_in_SymbolAttributeMapping(Symbol_Attribute_Datagrid.CurrentCell.Value)
                End If
            End If
        Catch ex As Exception
            WriteLog("Error in 'Symbol_Attribute_Datagrid_CurrentCellDirtyStateChanged' subprocess : " + ex.Message)
            PropStreamWriterObject.Close()
            BrewPID_MainForm.Close()
        End Try

    End Sub

    ''' <summary>
    ''' 'BrewPID_SymbolAttributesForm_Load' subprocess defines what happens when the BrewPID_SymbolAttributesForm loads
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub BrewPID_SymbolAttributesForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Dim file_path As String
            'Check which tab of the TabControl_BrewPID of the BrewPID_MainForm is active and choose the file_path accordingly
            If BrewPID_MainForm.TabControl_BrewPID.SelectedIndex = 0 Then
                file_path = BrewPID_MainForm.Component_Text_Path.Text
            Else
                file_path = BrewPID_MainForm.Pipeline_Text_Path.Text
            End If
            'Check if the Symbol_Attribute_Mapping.csv is empty or not
            If File.ReadAllText(Path.GetDirectoryName(file_path) + "\Symbol_Attribute_Mapping.csv").Length <> 0 Then
                attributes_in_SymbolAttributeMapping = New Dictionary(Of String, String)
                'Convert the Symbol_Attribute_Mapping.csv to list
                Dim attributes_in_mapping_file As List(Of String) = File.ReadAllLines(Path.GetDirectoryName(file_path) + "\Symbol_Attribute_Mapping.csv").ToList()
                'Iterate through each entry of the attributes_in_mapping_file list and add them to the attributes_in_SymbolAttributeMapping dictionary
                For Each single_row In attributes_in_mapping_file
                    attributes_in_SymbolAttributeMapping.Add(single_row.Split(",")(1), single_row.Split(",")(0))
                Next
            End If
        Catch ex As Exception
            WriteLog("Error in 'BrewPID_SymbolAttributesForm_Load' subprocess : " + ex.Message)
            PropStreamWriterObject.Close()
            BrewPID_MainForm.Close()
        End Try
    End Sub

End Class