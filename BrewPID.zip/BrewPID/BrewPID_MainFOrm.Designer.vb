﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class BrewPID_MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BrewPID_MainForm))
        Me.BrewPID_Button_Submit = New System.Windows.Forms.Button()
        Me.OpenFileDialog_1 = New System.Windows.Forms.OpenFileDialog()
        Me.TabControl_BrewPID = New System.Windows.Forms.TabControl()
        Me.TabPage_Component = New System.Windows.Forms.TabPage()
        Me.Component_Button_Add_Attribute = New System.Windows.Forms.Button()
        Me.Component_Text_Name = New System.Windows.Forms.ComboBox()
        Me.Component_Label_Name = New System.Windows.Forms.Label()
        Me.Component_Button_Access_Mapping = New System.Windows.Forms.Button()
        Me.Component_Label_Symbol_Mapping = New System.Windows.Forms.Label()
        Me.Component_Text_Rotation = New System.Windows.Forms.ComboBox()
        Me.Component_Text_Y = New System.Windows.Forms.ComboBox()
        Me.Component_Text_X = New System.Windows.Forms.ComboBox()
        Me.Component_Button_Browse = New System.Windows.Forms.Button()
        Me.Component_Text_Unit = New System.Windows.Forms.ComboBox()
        Me.Component_Label_Unit = New System.Windows.Forms.Label()
        Me.Component_Text_Path = New System.Windows.Forms.TextBox()
        Me.Component_Label_Rotation = New System.Windows.Forms.Label()
        Me.Component_Label_Y = New System.Windows.Forms.Label()
        Me.Component_Label_X = New System.Windows.Forms.Label()
        Me.Component_Label_Path = New System.Windows.Forms.Label()
        Me.TabPage_Pipeline = New System.Windows.Forms.TabPage()
        Me.Pipeline_Button_Add_Attribute = New System.Windows.Forms.Button()
        Me.Pipeline_Text_Name = New System.Windows.Forms.ComboBox()
        Me.Pipeline_Label_Name = New System.Windows.Forms.Label()
        Me.Pipeline_Button_Access_Mapping = New System.Windows.Forms.Button()
        Me.Pipeline_Label_Symbol_Mapping = New System.Windows.Forms.Label()
        Me.Pipeline_Text_EndY = New System.Windows.Forms.ComboBox()
        Me.Pipeline_Text_EndX = New System.Windows.Forms.ComboBox()
        Me.Pipeline_Text_StartY = New System.Windows.Forms.ComboBox()
        Me.Pipeline_Text_StartX = New System.Windows.Forms.ComboBox()
        Me.Pipeline_Button_Browse = New System.Windows.Forms.Button()
        Me.Pipeline_Text_Unit = New System.Windows.Forms.ComboBox()
        Me.Pipeline_Label_Unit = New System.Windows.Forms.Label()
        Me.Pipeline_Text_Path = New System.Windows.Forms.TextBox()
        Me.Pipeline_Label_EndY = New System.Windows.Forms.Label()
        Me.Pipeline_Label_EndX = New System.Windows.Forms.Label()
        Me.Pipeline_Label_StartY = New System.Windows.Forms.Label()
        Me.Pipeline_Label_StartX = New System.Windows.Forms.Label()
        Me.Pipeline_Label_Path = New System.Windows.Forms.Label()
        Me.TabPage_SPPID = New System.Windows.Forms.TabPage()
        Me.SPPID_Text_Index = New System.Windows.Forms.TextBox()
        Me.SPPID_Label_Unit = New System.Windows.Forms.Label()
        Me.SPPID_Text_Unit = New System.Windows.Forms.ComboBox()
        Me.SPPID_Label_Index = New System.Windows.Forms.Label()
        Me.SPPID_Text_Density = New System.Windows.Forms.TextBox()
        Me.SPPID_Label_Density = New System.Windows.Forms.Label()
        Me.BrewPID_Button_Cancel = New System.Windows.Forms.Button()
        Me.TabControl_BrewPID.SuspendLayout()
        Me.TabPage_Component.SuspendLayout()
        Me.TabPage_Pipeline.SuspendLayout()
        Me.TabPage_SPPID.SuspendLayout()
        Me.SuspendLayout()
        '
        'BrewPID_Button_Submit
        '
        Me.BrewPID_Button_Submit.Location = New System.Drawing.Point(12, 486)
        Me.BrewPID_Button_Submit.Name = "BrewPID_Button_Submit"
        Me.BrewPID_Button_Submit.Size = New System.Drawing.Size(75, 23)
        Me.BrewPID_Button_Submit.TabIndex = 53
        Me.BrewPID_Button_Submit.Text = "Submit"
        Me.BrewPID_Button_Submit.UseVisualStyleBackColor = True
        '
        'OpenFileDialog_1
        '
        Me.OpenFileDialog_1.FileName = "OpenFileDialog1"
        Me.OpenFileDialog_1.Filter = "CSV files|*.csv"
        '
        'TabControl_BrewPID
        '
        Me.TabControl_BrewPID.Controls.Add(Me.TabPage_Component)
        Me.TabControl_BrewPID.Controls.Add(Me.TabPage_Pipeline)
        Me.TabControl_BrewPID.Controls.Add(Me.TabPage_SPPID)
        Me.TabControl_BrewPID.Location = New System.Drawing.Point(12, 2)
        Me.TabControl_BrewPID.Name = "TabControl_BrewPID"
        Me.TabControl_BrewPID.SelectedIndex = 0
        Me.TabControl_BrewPID.Size = New System.Drawing.Size(760, 478)
        Me.TabControl_BrewPID.TabIndex = 57
        '
        'TabPage_Component
        '
        Me.TabPage_Component.Controls.Add(Me.Component_Button_Add_Attribute)
        Me.TabPage_Component.Controls.Add(Me.Component_Text_Name)
        Me.TabPage_Component.Controls.Add(Me.Component_Label_Name)
        Me.TabPage_Component.Controls.Add(Me.Component_Button_Access_Mapping)
        Me.TabPage_Component.Controls.Add(Me.Component_Label_Symbol_Mapping)
        Me.TabPage_Component.Controls.Add(Me.Component_Text_Rotation)
        Me.TabPage_Component.Controls.Add(Me.Component_Text_Y)
        Me.TabPage_Component.Controls.Add(Me.Component_Text_X)
        Me.TabPage_Component.Controls.Add(Me.Component_Button_Browse)
        Me.TabPage_Component.Controls.Add(Me.Component_Text_Unit)
        Me.TabPage_Component.Controls.Add(Me.Component_Label_Unit)
        Me.TabPage_Component.Controls.Add(Me.Component_Text_Path)
        Me.TabPage_Component.Controls.Add(Me.Component_Label_Rotation)
        Me.TabPage_Component.Controls.Add(Me.Component_Label_Y)
        Me.TabPage_Component.Controls.Add(Me.Component_Label_X)
        Me.TabPage_Component.Controls.Add(Me.Component_Label_Path)
        Me.TabPage_Component.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_Component.Name = "TabPage_Component"
        Me.TabPage_Component.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Component.Size = New System.Drawing.Size(945, 452)
        Me.TabPage_Component.TabIndex = 0
        Me.TabPage_Component.Text = "Component File"
        Me.TabPage_Component.UseVisualStyleBackColor = True
        '
        'Component_Button_Add_Attribute
        '
        Me.Component_Button_Add_Attribute.Location = New System.Drawing.Point(165, 285)
        Me.Component_Button_Add_Attribute.Name = "Component_Button_Add_Attribute"
        Me.Component_Button_Add_Attribute.Size = New System.Drawing.Size(163, 23)
        Me.Component_Button_Add_Attribute.TabIndex = 64
        Me.Component_Button_Add_Attribute.Text = "Click Here to Add Attributes"
        Me.Component_Button_Add_Attribute.UseVisualStyleBackColor = True
        '
        'Component_Text_Name
        '
        Me.Component_Text_Name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Component_Text_Name.FormattingEnabled = True
        Me.Component_Text_Name.Location = New System.Drawing.Point(167, 61)
        Me.Component_Text_Name.Name = "Component_Text_Name"
        Me.Component_Text_Name.Size = New System.Drawing.Size(121, 21)
        Me.Component_Text_Name.TabIndex = 61
        '
        'Component_Label_Name
        '
        Me.Component_Label_Name.AutoSize = True
        Me.Component_Label_Name.Location = New System.Drawing.Point(38, 69)
        Me.Component_Label_Name.Name = "Component_Label_Name"
        Me.Component_Label_Name.Size = New System.Drawing.Size(72, 13)
        Me.Component_Label_Name.TabIndex = 60
        Me.Component_Label_Name.Text = "Symbol Name"
        '
        'Component_Button_Access_Mapping
        '
        Me.Component_Button_Access_Mapping.Location = New System.Drawing.Point(166, 93)
        Me.Component_Button_Access_Mapping.Name = "Component_Button_Access_Mapping"
        Me.Component_Button_Access_Mapping.Size = New System.Drawing.Size(251, 23)
        Me.Component_Button_Access_Mapping.TabIndex = 59
        Me.Component_Button_Access_Mapping.Text = "&Click Here to access Symbol Mapping form"
        Me.Component_Button_Access_Mapping.UseVisualStyleBackColor = True
        '
        'Component_Label_Symbol_Mapping
        '
        Me.Component_Label_Symbol_Mapping.AutoSize = True
        Me.Component_Label_Symbol_Mapping.Location = New System.Drawing.Point(38, 103)
        Me.Component_Label_Symbol_Mapping.Name = "Component_Label_Symbol_Mapping"
        Me.Component_Label_Symbol_Mapping.Size = New System.Drawing.Size(85, 13)
        Me.Component_Label_Symbol_Mapping.TabIndex = 58
        Me.Component_Label_Symbol_Mapping.Text = "Symbol Mapping"
        '
        'Component_Text_Rotation
        '
        Me.Component_Text_Rotation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Component_Text_Rotation.FormattingEnabled = True
        Me.Component_Text_Rotation.Location = New System.Drawing.Point(165, 208)
        Me.Component_Text_Rotation.Name = "Component_Text_Rotation"
        Me.Component_Text_Rotation.Size = New System.Drawing.Size(121, 21)
        Me.Component_Text_Rotation.TabIndex = 57
        '
        'Component_Text_Y
        '
        Me.Component_Text_Y.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Component_Text_Y.FormattingEnabled = True
        Me.Component_Text_Y.Location = New System.Drawing.Point(165, 171)
        Me.Component_Text_Y.Name = "Component_Text_Y"
        Me.Component_Text_Y.Size = New System.Drawing.Size(121, 21)
        Me.Component_Text_Y.TabIndex = 54
        '
        'Component_Text_X
        '
        Me.Component_Text_X.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Component_Text_X.FormattingEnabled = True
        Me.Component_Text_X.Location = New System.Drawing.Point(165, 132)
        Me.Component_Text_X.Name = "Component_Text_X"
        Me.Component_Text_X.Size = New System.Drawing.Size(121, 21)
        Me.Component_Text_X.TabIndex = 53
        '
        'Component_Button_Browse
        '
        Me.Component_Button_Browse.Location = New System.Drawing.Point(576, 26)
        Me.Component_Button_Browse.Name = "Component_Button_Browse"
        Me.Component_Button_Browse.Size = New System.Drawing.Size(75, 23)
        Me.Component_Button_Browse.TabIndex = 52
        Me.Component_Button_Browse.Text = "&Browse"
        Me.Component_Button_Browse.UseVisualStyleBackColor = True
        '
        'Component_Text_Unit
        '
        Me.Component_Text_Unit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Component_Text_Unit.FormattingEnabled = True
        Me.Component_Text_Unit.Items.AddRange(New Object() {"inches", "mm"})
        Me.Component_Text_Unit.Location = New System.Drawing.Point(165, 245)
        Me.Component_Text_Unit.Name = "Component_Text_Unit"
        Me.Component_Text_Unit.Size = New System.Drawing.Size(121, 21)
        Me.Component_Text_Unit.TabIndex = 51
        '
        'Component_Label_Unit
        '
        Me.Component_Label_Unit.AutoSize = True
        Me.Component_Label_Unit.Location = New System.Drawing.Point(38, 248)
        Me.Component_Label_Unit.Name = "Component_Label_Unit"
        Me.Component_Label_Unit.Size = New System.Drawing.Size(26, 13)
        Me.Component_Label_Unit.TabIndex = 48
        Me.Component_Label_Unit.Text = "Unit"
        '
        'Component_Text_Path
        '
        Me.Component_Text_Path.Location = New System.Drawing.Point(166, 29)
        Me.Component_Text_Path.Name = "Component_Text_Path"
        Me.Component_Text_Path.ReadOnly = True
        Me.Component_Text_Path.Size = New System.Drawing.Size(404, 20)
        Me.Component_Text_Path.TabIndex = 43
        '
        'Component_Label_Rotation
        '
        Me.Component_Label_Rotation.AutoSize = True
        Me.Component_Label_Rotation.Location = New System.Drawing.Point(38, 211)
        Me.Component_Label_Rotation.Name = "Component_Label_Rotation"
        Me.Component_Label_Rotation.Size = New System.Drawing.Size(84, 13)
        Me.Component_Label_Rotation.TabIndex = 42
        Me.Component_Label_Rotation.Text = "Symbol Rotation"
        '
        'Component_Label_Y
        '
        Me.Component_Label_Y.AutoSize = True
        Me.Component_Label_Y.Location = New System.Drawing.Point(38, 174)
        Me.Component_Label_Y.Name = "Component_Label_Y"
        Me.Component_Label_Y.Size = New System.Drawing.Size(68, 13)
        Me.Component_Label_Y.TabIndex = 39
        Me.Component_Label_Y.Text = "Y Coordinate"
        '
        'Component_Label_X
        '
        Me.Component_Label_X.AutoSize = True
        Me.Component_Label_X.Location = New System.Drawing.Point(38, 140)
        Me.Component_Label_X.Name = "Component_Label_X"
        Me.Component_Label_X.Size = New System.Drawing.Size(68, 13)
        Me.Component_Label_X.TabIndex = 38
        Me.Component_Label_X.Text = "X Coordinate"
        '
        'Component_Label_Path
        '
        Me.Component_Label_Path.AutoSize = True
        Me.Component_Label_Path.Location = New System.Drawing.Point(38, 36)
        Me.Component_Label_Path.Name = "Component_Label_Path"
        Me.Component_Label_Path.Size = New System.Drawing.Size(29, 13)
        Me.Component_Label_Path.TabIndex = 36
        Me.Component_Label_Path.Text = "Path"
        '
        'TabPage_Pipeline
        '
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Button_Add_Attribute)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Text_Name)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Label_Name)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Button_Access_Mapping)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Label_Symbol_Mapping)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Text_EndY)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Text_EndX)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Text_StartY)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Text_StartX)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Button_Browse)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Text_Unit)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Label_Unit)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Text_Path)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Label_EndY)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Label_EndX)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Label_StartY)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Label_StartX)
        Me.TabPage_Pipeline.Controls.Add(Me.Pipeline_Label_Path)
        Me.TabPage_Pipeline.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_Pipeline.Name = "TabPage_Pipeline"
        Me.TabPage_Pipeline.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Pipeline.Size = New System.Drawing.Size(752, 452)
        Me.TabPage_Pipeline.TabIndex = 1
        Me.TabPage_Pipeline.Text = "Pipeline File"
        Me.TabPage_Pipeline.UseVisualStyleBackColor = True
        '
        'Pipeline_Button_Add_Attribute
        '
        Me.Pipeline_Button_Add_Attribute.Location = New System.Drawing.Point(156, 330)
        Me.Pipeline_Button_Add_Attribute.Name = "Pipeline_Button_Add_Attribute"
        Me.Pipeline_Button_Add_Attribute.Size = New System.Drawing.Size(163, 23)
        Me.Pipeline_Button_Add_Attribute.TabIndex = 79
        Me.Pipeline_Button_Add_Attribute.Text = "Click Here to Add Attributes"
        Me.Pipeline_Button_Add_Attribute.UseVisualStyleBackColor = True
        '
        'Pipeline_Text_Name
        '
        Me.Pipeline_Text_Name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Pipeline_Text_Name.FormattingEnabled = True
        Me.Pipeline_Text_Name.Location = New System.Drawing.Point(156, 71)
        Me.Pipeline_Text_Name.Name = "Pipeline_Text_Name"
        Me.Pipeline_Text_Name.Size = New System.Drawing.Size(121, 21)
        Me.Pipeline_Text_Name.TabIndex = 78
        '
        'Pipeline_Label_Name
        '
        Me.Pipeline_Label_Name.AutoSize = True
        Me.Pipeline_Label_Name.Location = New System.Drawing.Point(36, 74)
        Me.Pipeline_Label_Name.Name = "Pipeline_Label_Name"
        Me.Pipeline_Label_Name.Size = New System.Drawing.Size(72, 13)
        Me.Pipeline_Label_Name.TabIndex = 77
        Me.Pipeline_Label_Name.Text = "Symbol Name"
        '
        'Pipeline_Button_Access_Mapping
        '
        Me.Pipeline_Button_Access_Mapping.Location = New System.Drawing.Point(156, 106)
        Me.Pipeline_Button_Access_Mapping.Name = "Pipeline_Button_Access_Mapping"
        Me.Pipeline_Button_Access_Mapping.Size = New System.Drawing.Size(251, 23)
        Me.Pipeline_Button_Access_Mapping.TabIndex = 76
        Me.Pipeline_Button_Access_Mapping.Text = "&Click Here to access Symbol Mapping form"
        Me.Pipeline_Button_Access_Mapping.UseVisualStyleBackColor = True
        '
        'Pipeline_Label_Symbol_Mapping
        '
        Me.Pipeline_Label_Symbol_Mapping.AutoSize = True
        Me.Pipeline_Label_Symbol_Mapping.Location = New System.Drawing.Point(36, 111)
        Me.Pipeline_Label_Symbol_Mapping.Name = "Pipeline_Label_Symbol_Mapping"
        Me.Pipeline_Label_Symbol_Mapping.Size = New System.Drawing.Size(85, 13)
        Me.Pipeline_Label_Symbol_Mapping.TabIndex = 75
        Me.Pipeline_Label_Symbol_Mapping.Text = "Symbol Mapping"
        '
        'Pipeline_Text_EndY
        '
        Me.Pipeline_Text_EndY.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Pipeline_Text_EndY.FormattingEnabled = True
        Me.Pipeline_Text_EndY.Location = New System.Drawing.Point(156, 256)
        Me.Pipeline_Text_EndY.Name = "Pipeline_Text_EndY"
        Me.Pipeline_Text_EndY.Size = New System.Drawing.Size(121, 21)
        Me.Pipeline_Text_EndY.TabIndex = 73
        '
        'Pipeline_Text_EndX
        '
        Me.Pipeline_Text_EndX.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Pipeline_Text_EndX.FormattingEnabled = True
        Me.Pipeline_Text_EndX.Location = New System.Drawing.Point(156, 218)
        Me.Pipeline_Text_EndX.Name = "Pipeline_Text_EndX"
        Me.Pipeline_Text_EndX.Size = New System.Drawing.Size(121, 21)
        Me.Pipeline_Text_EndX.TabIndex = 72
        '
        'Pipeline_Text_StartY
        '
        Me.Pipeline_Text_StartY.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Pipeline_Text_StartY.FormattingEnabled = True
        Me.Pipeline_Text_StartY.Location = New System.Drawing.Point(156, 180)
        Me.Pipeline_Text_StartY.Name = "Pipeline_Text_StartY"
        Me.Pipeline_Text_StartY.Size = New System.Drawing.Size(121, 21)
        Me.Pipeline_Text_StartY.TabIndex = 71
        '
        'Pipeline_Text_StartX
        '
        Me.Pipeline_Text_StartX.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Pipeline_Text_StartX.FormattingEnabled = True
        Me.Pipeline_Text_StartX.Location = New System.Drawing.Point(156, 143)
        Me.Pipeline_Text_StartX.Name = "Pipeline_Text_StartX"
        Me.Pipeline_Text_StartX.Size = New System.Drawing.Size(121, 21)
        Me.Pipeline_Text_StartX.TabIndex = 70
        '
        'Pipeline_Button_Browse
        '
        Me.Pipeline_Button_Browse.Location = New System.Drawing.Point(574, 32)
        Me.Pipeline_Button_Browse.Name = "Pipeline_Button_Browse"
        Me.Pipeline_Button_Browse.Size = New System.Drawing.Size(75, 23)
        Me.Pipeline_Button_Browse.TabIndex = 69
        Me.Pipeline_Button_Browse.Text = "Browse"
        Me.Pipeline_Button_Browse.UseVisualStyleBackColor = True
        '
        'Pipeline_Text_Unit
        '
        Me.Pipeline_Text_Unit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Pipeline_Text_Unit.FormattingEnabled = True
        Me.Pipeline_Text_Unit.Items.AddRange(New Object() {"inches", "mm"})
        Me.Pipeline_Text_Unit.Location = New System.Drawing.Point(156, 292)
        Me.Pipeline_Text_Unit.Name = "Pipeline_Text_Unit"
        Me.Pipeline_Text_Unit.Size = New System.Drawing.Size(121, 21)
        Me.Pipeline_Text_Unit.TabIndex = 68
        '
        'Pipeline_Label_Unit
        '
        Me.Pipeline_Label_Unit.AutoSize = True
        Me.Pipeline_Label_Unit.Location = New System.Drawing.Point(36, 295)
        Me.Pipeline_Label_Unit.Name = "Pipeline_Label_Unit"
        Me.Pipeline_Label_Unit.Size = New System.Drawing.Size(26, 13)
        Me.Pipeline_Label_Unit.TabIndex = 65
        Me.Pipeline_Label_Unit.Text = "Unit"
        '
        'Pipeline_Text_Path
        '
        Me.Pipeline_Text_Path.Location = New System.Drawing.Point(156, 35)
        Me.Pipeline_Text_Path.Name = "Pipeline_Text_Path"
        Me.Pipeline_Text_Path.ReadOnly = True
        Me.Pipeline_Text_Path.Size = New System.Drawing.Size(412, 20)
        Me.Pipeline_Text_Path.TabIndex = 60
        '
        'Pipeline_Label_EndY
        '
        Me.Pipeline_Label_EndY.AutoSize = True
        Me.Pipeline_Label_EndY.Location = New System.Drawing.Point(36, 259)
        Me.Pipeline_Label_EndY.Name = "Pipeline_Label_EndY"
        Me.Pipeline_Label_EndY.Size = New System.Drawing.Size(90, 13)
        Me.Pipeline_Label_EndY.TabIndex = 57
        Me.Pipeline_Label_EndY.Text = "End Y Coordinate"
        '
        'Pipeline_Label_EndX
        '
        Me.Pipeline_Label_EndX.AutoSize = True
        Me.Pipeline_Label_EndX.Location = New System.Drawing.Point(36, 221)
        Me.Pipeline_Label_EndX.Name = "Pipeline_Label_EndX"
        Me.Pipeline_Label_EndX.Size = New System.Drawing.Size(90, 13)
        Me.Pipeline_Label_EndX.TabIndex = 56
        Me.Pipeline_Label_EndX.Text = "End X Coordinate"
        '
        'Pipeline_Label_StartY
        '
        Me.Pipeline_Label_StartY.AutoSize = True
        Me.Pipeline_Label_StartY.Location = New System.Drawing.Point(36, 183)
        Me.Pipeline_Label_StartY.Name = "Pipeline_Label_StartY"
        Me.Pipeline_Label_StartY.Size = New System.Drawing.Size(93, 13)
        Me.Pipeline_Label_StartY.TabIndex = 55
        Me.Pipeline_Label_StartY.Text = "Start Y Coordinate"
        '
        'Pipeline_Label_StartX
        '
        Me.Pipeline_Label_StartX.AutoSize = True
        Me.Pipeline_Label_StartX.Location = New System.Drawing.Point(36, 146)
        Me.Pipeline_Label_StartX.Name = "Pipeline_Label_StartX"
        Me.Pipeline_Label_StartX.Size = New System.Drawing.Size(93, 13)
        Me.Pipeline_Label_StartX.TabIndex = 54
        Me.Pipeline_Label_StartX.Text = "Start X Coordinate"
        '
        'Pipeline_Label_Path
        '
        Me.Pipeline_Label_Path.AutoSize = True
        Me.Pipeline_Label_Path.Location = New System.Drawing.Point(36, 38)
        Me.Pipeline_Label_Path.Name = "Pipeline_Label_Path"
        Me.Pipeline_Label_Path.Size = New System.Drawing.Size(29, 13)
        Me.Pipeline_Label_Path.TabIndex = 53
        Me.Pipeline_Label_Path.Text = "Path"
        '
        'TabPage_SPPID
        '
        Me.TabPage_SPPID.Controls.Add(Me.SPPID_Text_Index)
        Me.TabPage_SPPID.Controls.Add(Me.SPPID_Label_Unit)
        Me.TabPage_SPPID.Controls.Add(Me.SPPID_Text_Unit)
        Me.TabPage_SPPID.Controls.Add(Me.SPPID_Label_Index)
        Me.TabPage_SPPID.Controls.Add(Me.SPPID_Text_Density)
        Me.TabPage_SPPID.Controls.Add(Me.SPPID_Label_Density)
        Me.TabPage_SPPID.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_SPPID.Name = "TabPage_SPPID"
        Me.TabPage_SPPID.Size = New System.Drawing.Size(945, 452)
        Me.TabPage_SPPID.TabIndex = 2
        Me.TabPage_SPPID.Text = "SPPID"
        Me.TabPage_SPPID.UseVisualStyleBackColor = True
        '
        'SPPID_Text_Index
        '
        Me.SPPID_Text_Index.Location = New System.Drawing.Point(161, 110)
        Me.SPPID_Text_Index.Name = "SPPID_Text_Index"
        Me.SPPID_Text_Index.Size = New System.Drawing.Size(100, 20)
        Me.SPPID_Text_Index.TabIndex = 66
        Me.SPPID_Text_Index.Text = "2"
        '
        'SPPID_Label_Unit
        '
        Me.SPPID_Label_Unit.AutoSize = True
        Me.SPPID_Label_Unit.Location = New System.Drawing.Point(41, 73)
        Me.SPPID_Label_Unit.Name = "SPPID_Label_Unit"
        Me.SPPID_Label_Unit.Size = New System.Drawing.Size(86, 13)
        Me.SPPID_Label_Unit.TabIndex = 65
        Me.SPPID_Label_Unit.Text = "Grid Density Unit"
        '
        'SPPID_Text_Unit
        '
        Me.SPPID_Text_Unit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SPPID_Text_Unit.FormattingEnabled = True
        Me.SPPID_Text_Unit.Items.AddRange(New Object() {"inches", "mm"})
        Me.SPPID_Text_Unit.Location = New System.Drawing.Point(161, 70)
        Me.SPPID_Text_Unit.Name = "SPPID_Text_Unit"
        Me.SPPID_Text_Unit.Size = New System.Drawing.Size(121, 21)
        Me.SPPID_Text_Unit.TabIndex = 64
        '
        'SPPID_Label_Index
        '
        Me.SPPID_Label_Index.AutoSize = True
        Me.SPPID_Label_Index.Location = New System.Drawing.Point(41, 113)
        Me.SPPID_Label_Index.Name = "SPPID_Label_Index"
        Me.SPPID_Label_Index.Size = New System.Drawing.Size(55, 13)
        Me.SPPID_Label_Index.TabIndex = 63
        Me.SPPID_Label_Index.Text = "Grid Index"
        '
        'SPPID_Text_Density
        '
        Me.SPPID_Text_Density.Location = New System.Drawing.Point(161, 33)
        Me.SPPID_Text_Density.Name = "SPPID_Text_Density"
        Me.SPPID_Text_Density.Size = New System.Drawing.Size(100, 20)
        Me.SPPID_Text_Density.TabIndex = 62
        Me.SPPID_Text_Density.Text = "2.50"
        '
        'SPPID_Label_Density
        '
        Me.SPPID_Label_Density.AutoSize = True
        Me.SPPID_Label_Density.Location = New System.Drawing.Point(41, 36)
        Me.SPPID_Label_Density.Name = "SPPID_Label_Density"
        Me.SPPID_Label_Density.Size = New System.Drawing.Size(64, 13)
        Me.SPPID_Label_Density.TabIndex = 61
        Me.SPPID_Label_Density.Text = "Grid Density"
        '
        'BrewPID_Button_Cancel
        '
        Me.BrewPID_Button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.BrewPID_Button_Cancel.Location = New System.Drawing.Point(697, 486)
        Me.BrewPID_Button_Cancel.Name = "BrewPID_Button_Cancel"
        Me.BrewPID_Button_Cancel.Size = New System.Drawing.Size(75, 23)
        Me.BrewPID_Button_Cancel.TabIndex = 67
        Me.BrewPID_Button_Cancel.Text = "Cancel"
        Me.BrewPID_Button_Cancel.UseVisualStyleBackColor = True
        '
        'BrewPID_MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.BrewPID_Button_Cancel
        Me.ClientSize = New System.Drawing.Size(784, 521)
        Me.Controls.Add(Me.BrewPID_Button_Cancel)
        Me.Controls.Add(Me.TabControl_BrewPID)
        Me.Controls.Add(Me.BrewPID_Button_Submit)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(993, 560)
        Me.MinimumSize = New System.Drawing.Size(800, 560)
        Me.Name = "BrewPID_MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "BrewPID"
        Me.TabControl_BrewPID.ResumeLayout(False)
        Me.TabPage_Component.ResumeLayout(False)
        Me.TabPage_Component.PerformLayout()
        Me.TabPage_Pipeline.ResumeLayout(False)
        Me.TabPage_Pipeline.PerformLayout()
        Me.TabPage_SPPID.ResumeLayout(False)
        Me.TabPage_SPPID.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BrewPID_Button_Submit As Button
    Friend WithEvents OpenFileDialog_1 As OpenFileDialog
    Friend WithEvents TabControl_BrewPID As TabControl
    Friend WithEvents TabPage_Component As TabPage
    Friend WithEvents Component_Button_Browse As Button
    Friend WithEvents Component_Text_Unit As ComboBox
    Friend WithEvents Component_Label_Unit As Label
    Friend WithEvents Component_Text_Path As TextBox
    Friend WithEvents Component_Label_Rotation As Label
    Friend WithEvents Component_Label_Y As Label
    Friend WithEvents Component_Label_X As Label
    Friend WithEvents Component_Label_Path As Label
    Friend WithEvents TabPage_Pipeline As TabPage
    Friend WithEvents Pipeline_Button_Browse As Button
    Friend WithEvents Pipeline_Text_Unit As ComboBox
    Friend WithEvents Pipeline_Label_Unit As Label
    Friend WithEvents Pipeline_Text_Path As TextBox
    Friend WithEvents Pipeline_Label_EndY As Label
    Friend WithEvents Pipeline_Label_EndX As Label
    Friend WithEvents Pipeline_Label_StartY As Label
    Friend WithEvents Pipeline_Label_StartX As Label
    Friend WithEvents Pipeline_Label_Path As Label
    Friend WithEvents TabPage_SPPID As TabPage
    Friend WithEvents SPPID_Text_Index As TextBox
    Friend WithEvents SPPID_Label_Unit As Label
    Friend WithEvents SPPID_Text_Unit As ComboBox
    Friend WithEvents SPPID_Label_Index As Label
    Friend WithEvents SPPID_Text_Density As TextBox
    Friend WithEvents SPPID_Label_Density As Label
    Friend WithEvents Component_Text_Rotation As ComboBox
    Friend WithEvents Component_Text_Y As ComboBox
    Friend WithEvents Component_Text_X As ComboBox
    Friend WithEvents Pipeline_Text_EndY As ComboBox
    Friend WithEvents Pipeline_Text_EndX As ComboBox
    Friend WithEvents Pipeline_Text_StartY As ComboBox
    Friend WithEvents Pipeline_Text_StartX As ComboBox
    Friend WithEvents BrewPID_Button_Cancel As Button
    Friend WithEvents Component_Label_Symbol_Mapping As Label
    Friend WithEvents Component_Button_Access_Mapping As Button
    Friend WithEvents Pipeline_Button_Access_Mapping As Button
    Friend WithEvents Pipeline_Label_Symbol_Mapping As Label
    Friend WithEvents Component_Text_Name As ComboBox
    Friend WithEvents Component_Label_Name As Label
    Friend WithEvents Pipeline_Text_Name As ComboBox
    Friend WithEvents Pipeline_Label_Name As Label
    Friend WithEvents Component_Button_Add_Attribute As Button
    Friend WithEvents Pipeline_Button_Add_Attribute As Button
End Class
