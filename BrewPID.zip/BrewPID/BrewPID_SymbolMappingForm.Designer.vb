﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BrewPID_SymbolMappingForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BrewPID_SymbolMappingForm))
        Me.Component_DataGrid = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Submit_Button = New System.Windows.Forms.Button()
        Me.OpenFileDialog_2 = New System.Windows.Forms.OpenFileDialog()
        Me.Remove_Symbol_Button = New System.Windows.Forms.Button()
        Me.Add_Symbol_Button = New System.Windows.Forms.Button()
        CType(Me.Component_DataGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Component_DataGrid
        '
        Me.Component_DataGrid.AllowUserToAddRows = False
        Me.Component_DataGrid.AllowUserToDeleteRows = False
        Me.Component_DataGrid.AllowUserToResizeColumns = False
        Me.Component_DataGrid.AllowUserToResizeRows = False
        Me.Component_DataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Component_DataGrid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4})
        Me.Component_DataGrid.Location = New System.Drawing.Point(12, 12)
        Me.Component_DataGrid.Name = "Component_DataGrid"
        Me.Component_DataGrid.Size = New System.Drawing.Size(1115, 427)
        Me.Component_DataGrid.TabIndex = 56
        '
        'Column1
        '
        Me.Column1.HeaderText = "Symbol Name"
        Me.Column1.Name = "Column1"
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column1.Width = 300
        '
        'Column2
        '
        Me.Column2.HeaderText = "Symbol Path"
        Me.Column2.MinimumWidth = 98
        Me.Column2.Name = "Column2"
        Me.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Column2.Width = 560
        '
        'Column3
        '
        Me.Column3.DataPropertyName = "(none)"
        Me.Column3.HeaderText = ""
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Column3.Text = "Browse"
        Me.Column3.Width = 40
        '
        'Column4
        '
        Me.Column4.HeaderText = "Symbol Type"
        Me.Column4.Items.AddRange(New Object() {"Design", "Label", "Piping Comp", "Instrument", "Main Equipment", "Sub Equipment", "Line"})
        Me.Column4.Name = "Column4"
        Me.Column4.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column4.Width = 170
        '
        'Submit_Button
        '
        Me.Submit_Button.Location = New System.Drawing.Point(1012, 458)
        Me.Submit_Button.Name = "Submit_Button"
        Me.Submit_Button.Size = New System.Drawing.Size(115, 23)
        Me.Submit_Button.TabIndex = 59
        Me.Submit_Button.Text = "Submit  "
        Me.Submit_Button.UseVisualStyleBackColor = True
        '
        'OpenFileDialog_2
        '
        Me.OpenFileDialog_2.FileName = "OpenFileDialog1"
        '
        'Remove_Symbol_Button
        '
        Me.Remove_Symbol_Button.Location = New System.Drawing.Point(166, 458)
        Me.Remove_Symbol_Button.Name = "Remove_Symbol_Button"
        Me.Remove_Symbol_Button.Size = New System.Drawing.Size(97, 23)
        Me.Remove_Symbol_Button.TabIndex = 60
        Me.Remove_Symbol_Button.Text = "Remove Symbol"
        Me.Remove_Symbol_Button.UseVisualStyleBackColor = True
        '
        'Add_Symbol_Button
        '
        Me.Add_Symbol_Button.Location = New System.Drawing.Point(12, 458)
        Me.Add_Symbol_Button.Name = "Add_Symbol_Button"
        Me.Add_Symbol_Button.Size = New System.Drawing.Size(121, 23)
        Me.Add_Symbol_Button.TabIndex = 61
        Me.Add_Symbol_Button.Text = "Add Symbol"
        Me.Add_Symbol_Button.UseVisualStyleBackColor = True
        '
        'BrewPID_SymbolMappingForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1139, 493)
        Me.Controls.Add(Me.Add_Symbol_Button)
        Me.Controls.Add(Me.Remove_Symbol_Button)
        Me.Controls.Add(Me.Submit_Button)
        Me.Controls.Add(Me.Component_DataGrid)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(1155, 532)
        Me.MinimumSize = New System.Drawing.Size(1155, 532)
        Me.Name = "BrewPID_SymbolMappingForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "BrewPID Symbol Mapping"
        CType(Me.Component_DataGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Component_DataGrid As DataGridView
    Friend WithEvents Submit_Button As Button
    Friend WithEvents OpenFileDialog_2 As OpenFileDialog
    Friend WithEvents Remove_Symbol_Button As Button
    Friend WithEvents Add_Symbol_Button As Button
    Friend WithEvents Column1 As DataGridViewComboBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewButtonColumn
    Friend WithEvents Column4 As DataGridViewComboBoxColumn
End Class
